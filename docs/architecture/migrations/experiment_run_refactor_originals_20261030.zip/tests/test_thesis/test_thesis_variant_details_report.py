from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest
from scripts.research.thesis.evaluation.report_variant_details import (
    _annotate_trade_outcome,
    _flatten_markdown_rows,
    _markdown_config_results,
    _report_value,
    _trade_chart,
    _trade_outcome_caption,
    _validate_markdown_images,
    _validate_report_figures,
)


@pytest.mark.parametrize(
    ("value", "field", "expected"),
    [
        (0.101815, "max_drawdown", "10.18%"),
        (0.1, "peak_trailing_dd_limit", "10.00%"),
        (12.571, "total_return_pct", "12.57%"),
        (0.0003, "learning_rate", "0.0003"),
        (250.0, "net_pnl", "250.000"),
    ],
)
def test_report_value_formats_percentages_with_units(
    value: float, field: str, expected: str
) -> None:
    assert _report_value(value, field) == expected


def test_nested_parameters_render_as_readable_rows_without_raw_objects() -> None:
    rows = _flatten_markdown_rows(
        {
            "policy": {
                "learning_rate": 0.0003,
                "risk_frac_range": [0.0, 0.01],
                "layers": [64, 32],
                "enabled": True,
            }
        }
    )

    assert rows == [
        ("policy / learning rate", "0.0003"),
        ("policy / risk frac range", "0.00%, 1.00%"),
        ("policy / layers", "64, 32"),
        ("policy / enabled", "Yes"),
    ]
    assert "{" not in str(rows)
    assert "}" not in str(rows)


@pytest.mark.parametrize(
    ("category", "split", "rank", "trade", "expected"),
    [
        (
            "winners",
            "training",
            2,
            {"net_pnl": 125.5},
            "TYPICAL WINNER | TRAINING | SAMPLE 2 | NET PNL +125.50 account units",
        ),
        (
            "losers",
            "testing",
            1,
            {"net_pnl": -42.0},
            "TYPICAL LOSER | TESTING | SAMPLE 1 | NET PNL -42.00 account units",
        ),
        (
            "breakeven",
            "training",
            1,
            {},
            "TYPICAL BREAK-EVEN | TRAINING | SAMPLE 1 | NET PNL not recorded",
        ),
    ],
)
def test_trade_outcome_caption_is_explicit(
    category: str, split: str, rank: int, trade: dict[str, Any], expected: str
) -> None:
    assert _trade_outcome_caption(category, split, rank, trade) == expected


def test_markdown_image_validation_rejects_missing_plot(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError, match="missing or empty figures"):
        _validate_markdown_images("![required plot](figures/missing.png)", tmp_path)


def test_markdown_image_validation_accepts_absolute_plot(tmp_path: Path) -> None:
    image = tmp_path / "equity.png"
    image.write_bytes(b"png")

    _validate_markdown_images(f"![required plot]({image})", tmp_path)


def test_config_results_report_is_concise_and_uses_absolute_figure_links(tmp_path: Path) -> None:
    report = {
        "campaign_id": "pilot",
        "fingerprint": "abc123",
        "project_context": {
            "run_evidence": [
                {
                    "variant": "ladder_a4a",
                    "split": {
                        "train_start": "2024-12-30",
                        "train_end": "2025-12-31",
                        "test_start": "2026-01-01",
                    },
                    "datasets": [
                        {
                            "name": "test_bars",
                            "start": "2026-01-02 01:05:00+03:00",
                            "end": "2026-10-16 23:49:00+03:00",
                        }
                    ],
                    "evaluation": {
                        "training_action_mode": "stochastic",
                        "action_mode": "stochastic",
                        "action_mode_matches_training": True,
                        "tick_execution": True,
                        "random_fill_latency_ms": 30,
                        "test_role": "previously_inspected_holdout",
                    },
                    "model": {"algorithm": "PPO", "encoder": "TCN", "parameter_count": 12},
                },
                {
                    "variant": "ladder_a4b",
                    "split": {
                        "train_start": "2024-12-30",
                        "train_end": "2025-12-31",
                        "test_start": "2026-01-01",
                    },
                    "datasets": [],
                    "evaluation": {},
                    "model": {},
                },
            ]
        },
        "variants": [
            {
                "variant": "ladder_a4a",
                "training": {
                    "agent_parameters": {
                        "resolved_variant": {
                            "seed": 50,
                            "algo": "ppo",
                            "arch": "tcn",
                            "reward": "dsr",
                            "action_schema": {"width": 12},
                            "observation_schema": {"observation_width": 6},
                        },
                        "run_summary": {"timesteps_completed": 100},
                        "ppo": {
                            "total_timesteps": 100,
                            "n_steps": 4,
                            "batch_size": 8,
                            "n_epochs": 2,
                        },
                        "env": {
                            "n_envs": 2,
                            "entry_state_observation": False,
                            "risk_mode": "dynamic",
                            "risk_floor": 0.0005,
                            "peak_trailing_dd_limit": 0.1,
                        },
                    },
                    "run_summary": {"timesteps_completed": 100},
                    "training_equity_gate": {
                        "ok": False,
                        "max_peak_trailing_dd": 0.101,
                    },
                    "peak_trailing_dd_limit": 0.1,
                },
                "splits": {
                    "training": {
                        "metrics": {
                            "total_return_pct": 1.0,
                            "total_pnl": 1000,
                            "max_drawdown": 0.101,
                            "n_trades": 5,
                            "win_rate": 0.6,
                            "profit_factor": 1.2,
                            "avg_trade": 200,
                        },
                        "generated_figures": {
                            "equity_curve": "figures/train_equity.png",
                            "peak_drawdown": "figures/train_drawdown.png",
                        },
                    },
                    "testing": {
                        "metrics": {},
                        "generated_figures": {
                            "equity_curve": "figures/test_equity.png",
                            "peak_drawdown": "figures/test_drawdown.png",
                        },
                    },
                },
            },
            {
                "variant": "ladder_a4b",
                "training": {"agent_parameters": {}, "training_equity_gate": {"ok": True}},
                "splits": {
                    "training": {
                        "metrics": {},
                        "generated_figures": {
                            "equity_curve": "figures/b_train_equity.png",
                            "peak_drawdown": "figures/b_train_drawdown.png",
                        },
                    },
                    "testing": {
                        "metrics": {},
                        "generated_figures": {
                            "equity_curve": "figures/b_test_equity.png",
                            "peak_drawdown": "figures/b_test_drawdown.png",
                        },
                    },
                },
            },
        ],
    }

    markdown = _markdown_config_results(report, 1.0, tmp_path, tmp_path)

    assert "# 2M matched-run report: configuration and results" in markdown
    assert "| Entry state visible | No | Not recorded" in markdown
    assert "COMPLETED" in markdown
    assert "MISS (0.1000 percentage points over)" in markdown
    assert "Hard risk" in markdown
    assert "year-survival gate" not in markdown
    assert "10.10% / 10.00%" in markdown
    assert "previously_inspected_holdout" in markdown
    assert (
        f"![ladder_a4a training equity_curve]({tmp_path / 'figures/train_equity.png'})" in markdown
    )
    assert "Typical winning trades" not in markdown


def test_report_figure_contract_rejects_missing_required_plots(tmp_path: Path) -> None:
    report = {
        "variants": [
            {
                "variant": "ladder_a0",
                "training": {"generated_figures": {"learner_diagnostics": "learner.png"}},
                "splits": {"training": {"generated_figures": {"equity_curve": "equity.png"}}},
            }
        ]
    }

    with pytest.raises(
        RuntimeError,
        match="required training/testing comparison figures were not generated",
    ):
        _validate_report_figures(report, tmp_path)


def test_selected_trade_chart_gets_an_outcome_banner(tmp_path: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.image as mpimg
    import matplotlib.pyplot as plt

    chart_path = tmp_path / "trade.png"
    figure, axes = plt.subplots(figsize=(4, 2))
    axes.plot([0, 1], [0, 1])
    figure.savefig(chart_path)
    plt.close(figure)
    original_height = mpimg.imread(chart_path).shape[0]

    _annotate_trade_outcome(chart_path, "TYPICAL WINNER | TRAINING | SAMPLE 1", "winners")

    annotated = mpimg.imread(chart_path)
    assert annotated.shape[0] > original_height


def test_selected_trade_chart_lookup_uses_candle_timezone(tmp_path: Path) -> None:
    orders_dir = tmp_path / "training" / "orders"
    orders_dir.mkdir(parents=True)
    expected = orders_dir / "trade_0001_20250106_1718_1817_L_p278.6.png"
    expected.touch()
    trade = {
        "direction": 1,
        "chart_entry_time": "2025-01-06T14:18:00.008+00:00",
        "chart_exit_time": "2025-01-06T15:17:01.208+00:00",
    }

    result = _trade_chart(
        tmp_path / "training",
        trade,
        tmp_path,
        chart_timezone="Etc/GMT-3",
    )

    assert result == "training/orders/trade_0001_20250106_1718_1817_L_p278.6.png"
