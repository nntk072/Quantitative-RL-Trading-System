"""Tests for PO3/IFVG detection rules."""

from __future__ import annotations

from typing import Any, cast

import numpy as np
import pandas as pd
import pytest

from features.po3.fvg_detection import FVGConfig, detect_fvg
from features.po3.ifvg_detection import IFVGConfig, detect_ifvg_confirmation
from features.po3.trigger_rules import (
    EntryConfig,
    detect_entry_trigger,
    detect_htf_fvg,
    detect_ltf_ifvg,
    detect_po3_entries,
)
from features.po3.zones import build_fvg_zones, build_fvg_zones_for_plot


@pytest.fixture
def sample_bars() -> pd.DataFrame:
    """Create sample OHLC bars for testing."""
    dates = pd.date_range("2025-01-01", periods=100, freq="min")
    np.random.seed(42)

    # Create some price movement
    close = pd.Series(100 + np.cumsum(np.random.randn(100) * 0.1), index=dates)
    high = close + np.abs(np.random.randn(100) * 0.05)
    low = close - np.abs(np.random.randn(100) * 0.05)
    open_price = close.shift(1).fillna(close.iloc[0])
    volume = pd.Series(np.random.randint(100, 1000, size=100), index=dates)

    return pd.DataFrame(
        {"open": open_price, "high": high, "low": low, "close": close, "volume": volume},
        index=dates,
    )


class TestDetectFVG:
    """Tests for FVG detection."""

    def test_detect_fvg_returns_expected_columns(self, sample_bars: pd.DataFrame) -> None:
        """Test that FVG detection returns expected columns."""
        result = detect_fvg(sample_bars)
        assert "fvg_bullish" in result.columns
        assert "fvg_bearish" in result.columns
        assert "fvg_bullish_low" in result.columns
        assert "fvg_bullish_high" in result.columns
        assert "fvg_bearish_low" in result.columns
        assert "fvg_bearish_high" in result.columns

    def test_fvg_output_shape(self, sample_bars: pd.DataFrame) -> None:
        """Test that output has same length as input."""
        result = detect_fvg(sample_bars)
        assert len(result) == len(sample_bars)
        assert result.index.equals(sample_bars.index)

    def test_fvg_with_custom_config(self, sample_bars: pd.DataFrame) -> None:
        """Test FVG detection with custom minimum imbalance."""
        config = FVGConfig(min_imbalance_pts=0.5)
        result = detect_fvg(sample_bars, config=config)
        assert isinstance(result, pd.DataFrame)

    def test_fvg_binary_values(self, sample_bars: pd.DataFrame) -> None:
        """Test that FVG signals are binary (0 or 1)."""
        result = detect_fvg(sample_bars)
        assert set(result["fvg_bullish"].unique()).issubset({0, 1})
        assert set(result["fvg_bearish"].unique()).issubset({0, 1})


class TestDetectIFVGConfirmation:
    """Tests for IFVG confirmation detection."""

    def test_ifvg_returns_expected_columns(self, sample_bars: pd.DataFrame) -> None:
        """Test that IFVG confirmation returns expected columns."""
        fvg_result = detect_fvg(sample_bars)
        ifvg_result = detect_ifvg_confirmation(sample_bars, fvg_result)
        assert "ifvg_bullish_confirmed" in ifvg_result.columns
        assert "ifvg_bearish_confirmed" in ifvg_result.columns
        assert "ifvg_bullish_low" in ifvg_result.columns
        assert "ifvg_bullish_high" in ifvg_result.columns
        assert "ifvg_bearish_low" in ifvg_result.columns
        assert "ifvg_bearish_high" in ifvg_result.columns
        assert "ifvg_bullish_origin_bar" in ifvg_result.columns
        assert "ifvg_bearish_origin_bar" in ifvg_result.columns

    def test_ifvg_output_shape(self, sample_bars: pd.DataFrame) -> None:
        """Test that output has same length as input."""
        fvg_result = detect_fvg(sample_bars)
        ifvg_result = detect_ifvg_confirmation(sample_bars, fvg_result)
        assert len(ifvg_result) == len(sample_bars)

    def test_ifvg_with_custom_config(self, sample_bars: pd.DataFrame) -> None:
        """Test IFVG confirmation with custom threshold."""
        fvg_result = detect_fvg(sample_bars)
        config = IFVGConfig(close_through_threshold=0.3)
        ifvg_result = detect_ifvg_confirmation(sample_bars, fvg_result, config=config)
        assert isinstance(ifvg_result, pd.DataFrame)

    def test_optional_buffer_can_be_enabled_or_disabled(self) -> None:
        bars = pd.DataFrame(
            {
                "high": [10.0, 11.0, 12.05, 12.1],
                "low": [9.0, 10.5, 12.01, 12.04],
                "close": [9.5, 10.8, 12.02, 12.06],
            },
            index=pd.date_range("2025-01-01", periods=4, freq="min"),
        )
        fvg = detect_fvg(bars)

        enabled = detect_ifvg_confirmation(
            bars,
            fvg,
            IFVGConfig(close_through_threshold=0.1, close_through_buffer_enabled=True),
        )
        disabled = detect_ifvg_confirmation(
            bars,
            fvg,
            IFVGConfig(close_through_threshold=0.1, close_through_buffer_enabled=False),
        )
        lower = detect_ifvg_confirmation(
            bars,
            fvg,
            IFVGConfig(close_through_threshold=0.02, close_through_buffer_enabled=True),
        )

        assert enabled["ifvg_bullish_confirmed"].sum() == 0
        assert disabled["ifvg_bullish_confirmed"].iloc[3] == 1
        assert lower["ifvg_bullish_confirmed"].iloc[3] == 1

    def test_fvg_buffer_fraction_is_not_forced_to_ten_percent(self) -> None:
        config = FVGConfig(reaction_buffer_fraction=0.0)

        assert config.reaction_buffer_fraction == 0.0

    def test_ifvg_binary_values(self, sample_bars: pd.DataFrame) -> None:
        """Test that IFVG signals are binary (0 or 1)."""
        fvg_result = detect_fvg(sample_bars)
        ifvg_result = detect_ifvg_confirmation(sample_bars, fvg_result)
        assert set(ifvg_result["ifvg_bullish_confirmed"].unique()).issubset({0, 1})
        assert set(ifvg_result["ifvg_bearish_confirmed"].unique()).issubset({0, 1})


class TestDetectEntryTrigger:
    """Tests for entry trigger detection."""

    @pytest.fixture()
    def bullish_close_through_bars(self) -> pd.DataFrame:
        """FVG [10, 12.1], swept by two candles, then confirmed beyond their wick."""
        idx = pd.date_range("2025-01-01", periods=10, freq="1min")
        return pd.DataFrame(
            {
                "open": [9, 10, 11, 12, 13.2, 13.6, 12.5, 13.5, 13, 12],
                "high": [10, 11, 13, 13.5, 14, 14.5, 13, 14.2, 14, 13],
                "low": [9, 10, 12.1, 11, 13, 12.5, 11.8, 13.2, 12, 11],
                "close": [9, 10, 12.5, 12, 13.6, 13.5, 12, 14, 13, 12],
            },
            index=idx,
        )

    def test_entry_trigger_returns_expected_columns(self, sample_bars: pd.DataFrame) -> None:
        """Test that entry trigger returns expected columns."""
        fvg_result = detect_fvg(sample_bars)
        ifvg_result = detect_ifvg_confirmation(sample_bars, fvg_result)
        entry_result = detect_entry_trigger(sample_bars, ifvg_result)
        assert "entry_long" in entry_result.columns
        assert "entry_short" in entry_result.columns
        assert "entry_trigger_type" in entry_result.columns

    def test_entry_trigger_output_shape(self, sample_bars: pd.DataFrame) -> None:
        """Test that output has same length as input."""
        fvg_result = detect_fvg(sample_bars)
        ifvg_result = detect_ifvg_confirmation(sample_bars, fvg_result)
        entry_result = detect_entry_trigger(sample_bars, ifvg_result)
        assert len(entry_result) == len(sample_bars)

    def test_entry_trigger_with_retest_type(self, sample_bars: pd.DataFrame) -> None:
        """Test entry trigger with retest type."""
        fvg_result = detect_fvg(sample_bars)
        ifvg_result = detect_ifvg_confirmation(sample_bars, fvg_result)
        entry_result = detect_entry_trigger(sample_bars, ifvg_result, entry_type="retest")
        assert isinstance(entry_result, pd.DataFrame)

    def test_entry_trigger_with_close_through_type(self, sample_bars: pd.DataFrame) -> None:
        """Test entry trigger with close_through type."""
        fvg_result = detect_fvg(sample_bars)
        ifvg_result = detect_ifvg_confirmation(sample_bars, fvg_result)
        entry_result = detect_entry_trigger(sample_bars, ifvg_result, entry_type="close_through")
        assert isinstance(entry_result, pd.DataFrame)

    def test_entry_trigger_binary_values(self, sample_bars: pd.DataFrame) -> None:
        """Test that entry signals are binary (0 or 1)."""
        fvg_result = detect_fvg(sample_bars)
        ifvg_result = detect_ifvg_confirmation(sample_bars, fvg_result)
        entry_result = detect_entry_trigger(sample_bars, ifvg_result)
        assert set(entry_result["entry_long"].unique()).issubset({0, 1})
        assert set(entry_result["entry_short"].unique()).issubset({0, 1})

    def test_entry_trigger_with_custom_config(self, sample_bars: pd.DataFrame) -> None:
        """Test entry trigger with custom configuration."""
        fvg_result = detect_fvg(sample_bars)
        ifvg_result = detect_ifvg_confirmation(sample_bars, fvg_result)
        config = EntryConfig(retest_threshold=0.05)
        entry_result = detect_entry_trigger(sample_bars, ifvg_result, config=config)
        assert isinstance(entry_result, pd.DataFrame)

    def test_entry_trigger_ltf_fvg_fires_on_zone_reentry(
        self, bullish_close_through_bars: pd.DataFrame
    ) -> None:
        """The ltf_fvg entry fires when price re-enters a confirmed IFVG zone.

        Reuses the bullish close-through fixture. Price first re-enters the
        confirmed zone at bar 6, producing an LTF-FVG entry.
        """
        fvg = detect_fvg(bullish_close_through_bars)
        ifvg = detect_ifvg_confirmation(bullish_close_through_bars, fvg)
        entry = detect_entry_trigger(bullish_close_through_bars, ifvg, entry_type="ltf_fvg")

        assert entry["entry_long"].sum() > 0
        first = entry.index[entry["entry_long"] == 1][0]
        assert first == bullish_close_through_bars.index[6]
        assert entry.loc[bullish_close_through_bars.index[4], "entry_long"] == 0
        fired = entry.loc[entry["entry_trigger_type"] != ""]
        assert set(fired["entry_trigger_type"].unique()) == {"ltf_fvg"}

    def test_entry_trigger_ltf_fvg_not_a_pass(
        self, bullish_close_through_bars: pd.DataFrame
    ) -> None:
        """The placeholder pass must be gone: a run terminates and emits entries."""
        fvg = detect_fvg(bullish_close_through_bars)
        ifvg = detect_ifvg_confirmation(bullish_close_through_bars, fvg)
        entry = detect_entry_trigger(bullish_close_through_bars, ifvg, entry_type="ltf_fvg")
        assert len(entry) == len(bullish_close_through_bars)
        assert "entry_trigger_type" in entry.columns


class TestDetectHTFFVG:
    """Tests for HTF FVG detection."""

    def test_htf_fvg_returns_expected_columns(self, sample_bars: pd.DataFrame) -> None:
        """Test that HTF FVG detection returns expected columns."""
        result = detect_htf_fvg(sample_bars, htf="M5")
        assert "htf_fvg_bullish" in result.columns
        assert "htf_fvg_bearish" in result.columns
        assert "htf_fvg_bullish_low" in result.columns
        assert "htf_fvg_bullish_high" in result.columns
        assert "htf_fvg_bearish_low" in result.columns
        assert "htf_fvg_bearish_high" in result.columns

    def test_htf_fvg_output_shape(self, sample_bars: pd.DataFrame) -> None:
        """Test that output has same length as M1 input."""
        result = detect_htf_fvg(sample_bars, htf="M5")
        assert len(result) == len(sample_bars)
        assert result.index.equals(sample_bars.index)

    def test_htf_fvg_binary_values(self, sample_bars: pd.DataFrame) -> None:
        """Test that HTF FVG signals are binary (0 or 1)."""
        result = detect_htf_fvg(sample_bars, htf="M5")
        assert set(result["htf_fvg_bullish"].unique()).issubset({0, 1})
        assert set(result["htf_fvg_bearish"].unique()).issubset({0, 1})

    def test_htf_fvg_with_custom_config(self, sample_bars: pd.DataFrame) -> None:
        """Test HTF FVG detection with custom configuration."""
        config = FVGConfig(min_imbalance_pts=0.5)
        result = detect_htf_fvg(sample_bars, htf="M15", config=config)
        assert isinstance(result, pd.DataFrame)

    def test_htf_fvg_with_different_timeframes(self, sample_bars: pd.DataFrame) -> None:
        """Test HTF FVG detection with different timeframes."""
        for tf in ["M5", "M15", "M30"]:
            result = detect_htf_fvg(sample_bars, htf=tf)
            assert isinstance(result, pd.DataFrame)
            assert len(result) == len(sample_bars)


class TestDetectLTFIFVG:
    """Tests for LTF IFVG confirmation detection."""

    def test_ltf_ifvg_returns_expected_columns(self, sample_bars: pd.DataFrame) -> None:
        """Test that LTF IFVG detection returns expected columns."""
        result = detect_ltf_ifvg(sample_bars, primary_tf="M5")
        assert "ltf_ifvg_bullish_confirmed" in result.columns
        assert "ltf_ifvg_bearish_confirmed" in result.columns
        assert "ltf_ifvg_bullish_low" in result.columns
        assert "ltf_ifvg_bullish_high" in result.columns
        assert "ltf_ifvg_bearish_low" in result.columns
        assert "ltf_ifvg_bearish_high" in result.columns

    def test_ltf_ifvg_output_shape(self, sample_bars: pd.DataFrame) -> None:
        """Test that output has same length as M1 input."""
        result = detect_ltf_ifvg(sample_bars, primary_tf="M5")
        assert len(result) == len(sample_bars)
        assert result.index.equals(sample_bars.index)

    def test_ltf_ifvg_binary_values(self, sample_bars: pd.DataFrame) -> None:
        """Test that LTF IFVG signals are binary (0 or 1)."""
        result = detect_ltf_ifvg(sample_bars, primary_tf="M5")
        assert set(result["ltf_ifvg_bullish_confirmed"].unique()).issubset({0, 1})
        assert set(result["ltf_ifvg_bearish_confirmed"].unique()).issubset({0, 1})

    def test_ltf_ifvg_with_custom_configs(self, sample_bars: pd.DataFrame) -> None:
        """Test LTF IFVG detection with custom configurations."""
        fvg_config = FVGConfig(min_imbalance_pts=0.5)
        ifvg_config = IFVGConfig(close_through_threshold=0.3)
        result = detect_ltf_ifvg(
            sample_bars, primary_tf="M15", fvg_config=fvg_config, ifvg_config=ifvg_config
        )
        assert isinstance(result, pd.DataFrame)

    def test_ltf_ifvg_with_different_primary_timeframes(self, sample_bars: pd.DataFrame) -> None:
        """Test LTF IFVG detection with different primary timeframes."""
        for tf in ["M5", "M15", "M30"]:
            result = detect_ltf_ifvg(sample_bars, primary_tf=tf)
            assert isinstance(result, pd.DataFrame)
            assert len(result) == len(sample_bars)


class TestDetectPO3Entries:
    """Tests for unified PO3 entry detection."""

    def test_po3_entries_returns_expected_columns(self, sample_bars: pd.DataFrame) -> None:
        """Test that unified PO3 entry detection returns expected columns."""
        result = detect_po3_entries(sample_bars)
        # Check HTF FVG columns
        assert "htf_fvg_bullish" in result.columns
        assert "htf_fvg_bearish" in result.columns
        assert "htf_fvg_bullish_low" in result.columns
        assert "htf_fvg_bullish_high" in result.columns
        assert "htf_fvg_bearish_low" in result.columns
        assert "htf_fvg_bearish_high" in result.columns
        # Check LTF IFVG columns
        assert "ltf_ifvg_bullish_confirmed" in result.columns
        assert "ltf_ifvg_bearish_confirmed" in result.columns
        assert "ltf_ifvg_bullish_low" in result.columns
        assert "ltf_ifvg_bullish_high" in result.columns
        assert "ltf_ifvg_bearish_low" in result.columns
        assert "ltf_ifvg_bearish_high" in result.columns
        # Check entry columns
        assert "entry_long" in result.columns
        assert "entry_short" in result.columns
        assert "entry_trigger_type" in result.columns

    def test_po3_entries_output_shape(self, sample_bars: pd.DataFrame) -> None:
        """Test that output has same length as M1 input."""
        result = detect_po3_entries(sample_bars)
        assert len(result) == len(sample_bars)
        assert result.index.equals(sample_bars.index)

    def test_po3_entries_with_different_entry_types(self, sample_bars: pd.DataFrame) -> None:
        """Test unified PO3 entry detection with different entry types."""
        for entry_type in ["retest", "close_through"]:
            result = detect_po3_entries(sample_bars, entry_type=cast(Any, entry_type))
            assert isinstance(result, pd.DataFrame)
            assert len(result) == len(sample_bars)

    def test_po3_entries_with_custom_timeframes(self, sample_bars: pd.DataFrame) -> None:
        """Test unified PO3 entry detection with custom timeframes."""
        result = detect_po3_entries(sample_bars, htf="M30", primary_tf="M15")
        assert isinstance(result, pd.DataFrame)
        assert len(result) == len(sample_bars)

    def test_po3_entries_with_custom_configs(self, sample_bars: pd.DataFrame) -> None:
        """Test unified PO3 entry detection with custom configurations."""
        fvg_config = FVGConfig(min_imbalance_pts=0.5)
        ifvg_config = IFVGConfig(close_through_threshold=0.3)
        entry_config = EntryConfig(retest_threshold=0.05)
        result = detect_po3_entries(
            sample_bars,
            fvg_config=fvg_config,
            ifvg_config=ifvg_config,
            entry_config=entry_config,
        )
        assert isinstance(result, pd.DataFrame)


class TestIFVGConfirmationBehavior:
    """Behavioral tests: confirmations must actually fire on close-through data."""

    @pytest.fixture()
    def bullish_close_through_bars(self) -> pd.DataFrame:
        """Bars with a bullish FVG and causal wick-plus-buffer confirmation."""
        idx = pd.date_range("2025-01-01", periods=10, freq="1min")
        return pd.DataFrame(
            {
                "open": [9, 10, 11, 12, 13.2, 13.6, 12.5, 13.5, 13, 12],
                "high": [10, 11, 13, 13.5, 14, 14.5, 13, 14.2, 14, 13],
                "low": [9, 10, 12.1, 11, 13, 12.5, 11.8, 13.2, 12, 11],
                "close": [9, 10, 12.5, 12, 13.6, 13.5, 12, 14, 13, 12],
            },
            index=idx,
        )

    def test_bullish_ifvg_fires_on_close_through(
        self, bullish_close_through_bars: pd.DataFrame
    ) -> None:
        """A close through the FVG zone must mark the IFVG confirmed."""
        fvg = detect_fvg(bullish_close_through_bars)
        ifvg = detect_ifvg_confirmation(bullish_close_through_bars, fvg)
        assert ifvg["ifvg_bullish_confirmed"].sum() > 0
        # Zone bounds must be populated and match the FVG gap [bar1.high, bar3.low].
        confirmed = ifvg[ifvg["ifvg_bullish_confirmed"] == 1].iloc[0]
        assert confirmed["ifvg_bullish_low"] == 10.0
        assert confirmed["ifvg_bullish_high"] == 12.1

    def test_bearish_ifvg_fires_on_close_through(self) -> None:
        """A bearish FVG with closes below it must confirm."""
        idx = pd.date_range("2025-01-01", periods=10, freq="1min")
        bars = pd.DataFrame(
            {
                "open": [13, 12, 11, 11, 10, 9, 8, 8, 9, 10],
                "high": [14, 13, 11.9, 12.2, 10.5, 10, 9, 9, 10, 11],
                "low": [12, 11, 10, 9.8, 9.0, 8, 7, 7, 8, 9],
                "close": [13, 12, 10.5, 10.2, 9.7, 9, 8, 8, 9, 10],
            },
            index=idx,
        )
        fvg = detect_fvg(bars)
        ifvg = detect_ifvg_confirmation(bars, fvg)
        assert ifvg["ifvg_bearish_confirmed"].sum() > 0
        confirmed = ifvg[ifvg["ifvg_bearish_confirmed"] == 1].iloc[0]
        # Bearish FVG zone is [bar3.high, bar1.low] = [11.9, 12].
        assert confirmed["ifvg_bearish_low"] == 11.9
        assert confirmed["ifvg_bearish_high"] == 12.0

    def test_zero_threshold_still_requires_strictly_beyond_far_edge(self) -> None:
        bars = pd.DataFrame(
            {
                "high": [10.0, 11.0, 13.0, 13.0],
                "low": [9.0, 10.5, 12.0, 11.0],
                "close": [9.5, 10.8, 12.0, 10.0],
            },
            index=pd.date_range("2025-01-01", periods=4, freq="min"),
        )
        fvg = detect_fvg(bars)
        ifvg = detect_ifvg_confirmation(bars, fvg, config=IFVGConfig(close_through_threshold=0.0))

        assert ifvg["ifvg_bullish_confirmed"].iloc[2] == 0
        assert ifvg["ifvg_bullish_confirmed"].iloc[3] == 0

    def test_bullish_ifvg_inverts_a_bearish_fvg(self) -> None:
        bars = pd.DataFrame(
            {
                "high": [10.0, 9.5, 8.8, 9.5],
                "low": [9.0, 8.5, 8.0, 8.7],
                "close": [9.5, 9.0, 8.9, 9.1],
            },
            index=pd.date_range("2025-01-01", periods=4, freq="min"),
        )
        result = detect_ifvg_confirmation(
            bars,
            detect_fvg(bars),
            IFVGConfig(close_through_threshold=0.0, inverse_opposing_fvg=True),
        )

        assert result["ifvg_bullish_confirmed"].iloc[3] == 1
        assert result["ifvg_bullish_low"].iloc[3] == 8.8
        assert result["ifvg_bullish_high"].iloc[3] == 9.0
        assert result["ifvg_bullish_origin_bar"].iloc[3] == 2

    def test_bearish_ifvg_inverts_a_bullish_fvg(self) -> None:
        bars = pd.DataFrame(
            {
                "high": [10.0, 10.5, 11.0, 10.5],
                "low": [9.0, 9.5, 10.2, 9.8],
                "close": [9.5, 10.0, 10.1, 9.9],
            },
            index=pd.date_range("2025-01-01", periods=4, freq="min"),
        )
        result = detect_ifvg_confirmation(
            bars,
            detect_fvg(bars),
            IFVGConfig(close_through_threshold=0.0, inverse_opposing_fvg=True),
        )

        assert result["ifvg_bearish_confirmed"].iloc[3] == 1
        assert result["ifvg_bearish_low"].iloc[3] == 10.0
        assert result["ifvg_bearish_high"].iloc[3] == 10.2
        assert result["ifvg_bearish_origin_bar"].iloc[3] == 2


class TestBuildFVGZones:
    """Tests for the drawable zone builder."""

    @pytest.fixture()
    def fvg_bars(self) -> pd.DataFrame:
        """M1 bars whose M5 resample forms a bullish FVG (zone [11, 12] at 00:10).

        M5[0]  (00:00, bars 0-4):  high 11, low 9
        M5[1]  (00:05, bars 5-9):  high 11, low 9
        M5[2]  (00:10, bars 10-14): low 12   -> bar3.low > bar1.high => FVG
        M5[3]  (00:15, bars 15-19): high 14, low 12 (zone stays unfilled)
        """
        idx = pd.date_range("2025-01-01", periods=20, freq="1min")
        return pd.DataFrame(
            {
                "open": [
                    9,
                    9,
                    9,
                    9,
                    9,
                    10,
                    9,
                    9,
                    10,
                    9,
                    12,
                    12,
                    12,
                    12,
                    12,
                    13,
                    13,
                    12,
                    12,
                    12,
                ],
                "high": [
                    10,
                    11,
                    10,
                    11,
                    10,
                    11,
                    10,
                    11,
                    10,
                    10,
                    13,
                    14,
                    13,
                    14,
                    13,
                    14,
                    13,
                    14,
                    13,
                    14,
                ],
                "low": [
                    9,
                    9,
                    9,
                    9,
                    9,
                    9,
                    9,
                    9,
                    9,
                    9,
                    12,
                    12,
                    12,
                    12,
                    12,
                    12,
                    12,
                    12,
                    12,
                    12,
                ],
                "close": [
                    9,
                    10,
                    9,
                    10,
                    9,
                    10,
                    9,
                    10,
                    9,
                    9,
                    12,
                    13,
                    12,
                    13,
                    12,
                    13,
                    12,
                    13,
                    12,
                    13,
                ],
            },
            index=idx,
        )

    def test_zone_from_htf_fvg(self, fvg_bars: pd.DataFrame) -> None:
        """Each 0->1 signal run yields exactly one zone with correct bounds."""
        signals = detect_htf_fvg(fvg_bars, htf="M5")
        zones = build_fvg_zones(fvg_bars, signals)
        bullish = [z for z in zones if z.side == "bullish"]
        assert len(bullish) >= 1
        z = bullish[0]
        assert z.kind == "htf_fvg"
        assert z.confirmed is False
        assert z.zone_low == 11.0
        assert z.zone_high == 12.0
        assert z.start_ts < z.end_ts

    def test_zone_edge_dedup(self, fvg_bars: pd.DataFrame) -> None:
        """Forward-filled runs must not create many overlapping zones."""
        signals = detect_htf_fvg(fvg_bars, htf="M5")
        zones = build_fvg_zones(fvg_bars, signals)
        starts = [z.start_ts for z in zones if z.side == "bullish"]
        # The M5 H4 bar where FVG fires is one contiguous run -> 1 start.
        assert len(starts) <= 3

    def test_zone_invalidation_on_fill(self) -> None:
        """A zone is invalidated only after its candle body closes through it."""
        idx = pd.date_range("2025-01-01", periods=10, freq="1min")
        bars = pd.DataFrame(
            {
                "open": [9, 10, 11, 12, 12, 11, 10, 10, 11, 11],
                "high": [10, 11, 13, 13, 13, 12, 11, 11, 12, 12],
                "low": [9, 10, 12, 12, 12, 11, 10, 10, 11, 11],
                "close": [9, 10, 13, 12, 12, 11, 9.5, 10, 11, 11],
            },
            index=idx,
        )
        # Hand-build an HTF FVG signal run that later closes below its lower edge.
        signals = pd.DataFrame(
            {
                "htf_fvg_bullish": [0, 0, 1, 1, 1, 1, 1, 1, 1, 1],
                "htf_fvg_bullish_low": [
                    np.nan,
                    np.nan,
                    10.0,
                    10.0,
                    10.0,
                    10.0,
                    10.0,
                    10.0,
                    10.0,
                    10.0,
                ],
                "htf_fvg_bullish_high": [
                    np.nan,
                    np.nan,
                    12.0,
                    12.0,
                    12.0,
                    12.0,
                    12.0,
                    12.0,
                    12.0,
                    12.0,
                ],
            },
            index=idx,
        )
        zones = build_fvg_zones(bars, signals, max_zone_bars=20)
        assert len(zones) == 1
        assert zones[0].invalidated is True
        # Ends at bar 5 (index 6) — not the horizon.
        assert zones[0].end_ts == idx[6]

    def test_zone_horizon_expiry(self, fvg_bars: pd.DataFrame) -> None:
        """A never-filled zone ends at the max_zone_bars horizon."""
        signals = detect_htf_fvg(fvg_bars, htf="M5")
        zones = build_fvg_zones(fvg_bars, signals, max_zone_bars=3)
        bull = [z for z in zones if z.side == "bullish"]
        assert bull
        # The FVG forms in the M5 bar at 00:10, which only completes at 00:15,
        # so the zone is first observable at 00:15 (index 15) and, never being
        # filled, ends 3 bars later at 00:18.
        assert bull[0].invalidated is False
        assert bull[0].end_ts == fvg_bars.index[18]

    def test_empty_signals(self, fvg_bars: pd.DataFrame) -> None:
        """Missing signal columns return an empty zone list."""
        zones = build_fvg_zones(fvg_bars, pd.DataFrame(index=fvg_bars.index))
        assert zones == []


class TestMTFCausality:
    """Zero within-period lookahead for HTF FVG / LTF IFVG mapping.

    HTF bars are indexed by their *open* time (label=\"left\" in resample), so an
    HTF bar spanning [T, T+period) is not complete until the next HTF open.
    The M1 bar at time t must therefore only see signals of HTF bars already
    *completed* — never the HTF bar that is still forming.
    """

    @pytest.fixture()
    def causal_m5_bars(self) -> pd.DataFrame:
        """25 M1 bars -> 5 M5 periods; bullish FVG forms in M5[2], IFVG at M5[3].

        M5[0] (00:00, bars 0-4):  high 11, low 9
        M5[1] (00:05, bars 5-9):  high 11, low 9
        M5[2] (00:10, bars 10-14): low 12   -> FVG [11, 12] forms here
        M5[3] (00:15, bars 15-19): close 15 -> IFVG confirms beyond prior pass wick
        M5[4] (00:20, bars 20-24): close 13 (zone stays unfilled)
        """
        idx = pd.date_range("2025-01-01", periods=25, freq="1min")
        return pd.DataFrame(
            {
                "open": [
                    9,
                    9,
                    9,
                    9,
                    9,
                    10,
                    9,
                    9,
                    10,
                    9,
                    12,
                    12,
                    12,
                    12,
                    12,
                    13,
                    13,
                    12,
                    12,
                    12,
                    13,
                    13,
                    12,
                    12,
                    12,
                ],
                "high": [
                    10,
                    11,
                    10,
                    11,
                    10,
                    11,
                    10,
                    11,
                    10,
                    10,
                    13,
                    14,
                    13,
                    14,
                    13,
                    14,
                    13,
                    14,
                    13,
                    16,
                    14,
                    13,
                    14,
                    13,
                    14,
                ],
                "low": [
                    9,
                    9,
                    9,
                    9,
                    9,
                    9,
                    9,
                    9,
                    9,
                    9,
                    12,
                    12,
                    12,
                    12,
                    12,
                    12,
                    12,
                    12,
                    12,
                    12,
                    12,
                    12,
                    12,
                    12,
                    12,
                ],
                "close": [
                    9,
                    10,
                    9,
                    10,
                    9,
                    10,
                    9,
                    10,
                    9,
                    9,
                    12,
                    13,
                    12,
                    13,
                    12,
                    13,
                    12,
                    13,
                    12,
                    15,
                    13,
                    12,
                    13,
                    12,
                    13,
                ],
            },
            index=idx,
        )

    def test_htf_fvg_not_visible_within_own_period(self, causal_m5_bars) -> None:
        """The FVG forming at 00:10 must not be visible to M1 bars of that period."""
        sig = detect_htf_fvg(causal_m5_bars, htf="M5")
        bull = sig["htf_fvg_bullish"]
        # bars 10-14 belong to the M5 bar where the FVG forms -> still hidden
        assert (bull.iloc[10:15] == 0).all(), "FVG leaked to its own (unclosed) M5 period"
        # bar 00:16 sits in the period after that M5 bar closes -> visible
        assert sig.loc[pd.Timestamp("2025-01-01 00:16"), "htf_fvg_bullish"] == 1
        assert sig.loc[pd.Timestamp("2025-01-01 00:16"), "htf_fvg_bullish_low"] == 11.0
        assert sig.loc[pd.Timestamp("2025-01-01 00:16"), "htf_fvg_bullish_high"] == 12.0

    def test_ltf_ifvg_confirmation_not_visible_within_own_period(self, causal_m5_bars) -> None:
        """The IFVG confirming at 00:15 must only be visible from 00:20 onward."""
        sig = detect_ltf_ifvg(causal_m5_bars, primary_tf="M5")
        conf = sig["ltf_ifvg_bullish_confirmed"]
        # bars 15-19: confirmation happens in this M5 period -> still hidden
        assert (conf.iloc[15:20] == 0).all(), "IFVG confirmation leaked into its own period"
        # bar 00:20 is the first M1 bar of the period after confirmation -> visible
        assert sig.loc[pd.Timestamp("2025-01-01 00:20"), "ltf_ifvg_bullish_confirmed"] == 1

    def test_po3_entries_no_entry_before_confirmation_visible(self, causal_m5_bars) -> None:
        """detect_po3_entries must not fire retest entries before the confirmation is observable."""
        res = detect_po3_entries(causal_m5_bars, htf="M5", primary_tf="M5")
        pre = res.loc[: pd.Timestamp("2025-01-01 00:19"), "entry_long"]
        assert (pre == 0).all(), "entry fired before IFVG confirmation was observable"
        # once the confirmation (00:20) is visible, a close at 00:21 retests the
        # zone [11, 12] -> long entry fires
        assert res.loc[pd.Timestamp("2025-01-01 00:21"), "entry_long"] == 1

    def test_explicit_close_alignment_does_not_add_a_second_delay(self, causal_m5_bars) -> None:
        """Native timeframe signals first appear at their explicit close time."""
        from market_data.transforms.align import timeframe_close_times
        from market_data.transforms.resample import resample

        m5_bars = resample(causal_m5_bars, "M5")
        m5_closes = timeframe_close_times(m5_bars, "M5")

        htf = detect_htf_fvg(
            causal_m5_bars,
            htf="M5",
            timeframe_bars=m5_bars,
            availability_times=m5_closes,
        )
        assert (htf.loc[: pd.Timestamp("2025-01-01 00:14"), "htf_fvg_bullish"] == 0).all()
        assert htf.loc[pd.Timestamp("2025-01-01 00:15"), "htf_fvg_bullish"] == 1

        ltf = detect_ltf_ifvg(
            causal_m5_bars,
            primary_tf="M5",
            timeframe_bars=m5_bars,
            availability_times=m5_closes,
        )
        assert (
            ltf.loc["2025-01-01 00:15":"2025-01-01 00:19", "ltf_ifvg_bullish_confirmed"] == 0
        ).all()
        assert ltf.loc[pd.Timestamp("2025-01-01 00:20"), "ltf_ifvg_bullish_confirmed"] == 1


class TestBuildFVGZonesForPlot:
    """Plot-only zones: native HTF start at bar2 open, end at fill (no M1 cap)."""

    def _m15_bullish_gap_m1(self) -> pd.DataFrame:
        """Three M15 bars: bar1 high=100, bar3 low=110 → bullish FVG [100, 110].

        M1 spine covers 16:00–17:44 so the gap can later fill on a later M15 bar.
        """
        idx = pd.date_range("2025-01-02 16:00", periods=105, freq="1min", tz="Etc/GMT-3")
        open_ = np.full(105, 105.0)
        high = np.full(105, 106.0)
        low = np.full(105, 104.0)
        close = np.full(105, 105.0)
        # bar1 M15 (16:00–16:14): high capped at 100
        high[0:15] = 100.0
        low[0:15] = 95.0
        close[0:15] = 98.0
        open_[0:15] = 97.0
        # bar2 (16:15–16:29): middle of the gap
        high[15:30] = 108.0
        low[15:30] = 101.0
        close[15:30] = 107.0
        open_[15:30] = 100.0
        # bar3 (16:30–16:44): low = 110 → imbalance vs bar1 high
        high[30:45] = 115.0
        low[30:45] = 110.0
        close[30:45] = 112.0
        open_[30:45] = 111.0
        # Later M15 candle closes below zone_low=100, invalidating the zone.
        high[60:75] = 105.0
        low[60:75] = 99.0
        close[60:75] = 99.5
        open_[60:75] = 104.0
        return pd.DataFrame(
            {"open": open_, "high": high, "low": low, "close": close},
            index=idx,
        )

    def test_ltf_plot_zone_starts_two_candles_before_confirmation(self) -> None:
        """LTF box starts two candles left of the close-through bar."""
        idx = pd.date_range("2025-01-02 10:00", periods=25, freq="1min", tz="Etc/GMT-3")
        open_ = np.full(25, 105.0)
        high = np.full(25, 106.0)
        low = np.full(25, 104.0)
        close = np.full(25, 105.0)
        high[0:5] = 100.0
        low[0:5] = 95.0
        close[0:5] = 98.0
        high[10:15] = 115.0
        low[10:15] = 110.0
        close[10:15] = 112.0
        close[15:20] = 120.0
        high[15:20] = 121.0
        low[15:20] = 118.0
        open_[15:20] = 112.0
        bars = pd.DataFrame(
            {"open": open_, "high": high, "low": low, "close": close},
            index=idx,
        )
        zones = build_fvg_zones_for_plot(bars, htf="M15", ltf="M5")
        bull = [z for z in zones if z.kind == "ltf_ifvg" and z.side == "bullish"]
        assert bull, "expected an LTF bullish IFVG"
        assert bull[0].start_ts == pd.Timestamp("2025-01-02 10:05", tz="Etc/GMT-3")

    def test_plot_zone_starts_at_bar2_open(self) -> None:
        bars = self._m15_bullish_gap_m1()
        zones = build_fvg_zones_for_plot(bars, htf="M15", ltf="M5")
        bull = [z for z in zones if z.kind == "htf_fvg" and z.side == "bullish"]
        assert bull, "expected at least one HTF bullish plot zone"
        z = bull[0]
        assert z.start_ts == pd.Timestamp("2025-01-02 16:15", tz="Etc/GMT-3")
        assert z.zone_low == pytest.approx(100.0)
        assert z.zone_high == pytest.approx(110.0)

    def test_plot_zone_ends_at_fill_not_m1_cap(self) -> None:
        bars = self._m15_bullish_gap_m1()
        zones = build_fvg_zones_for_plot(bars, htf="M15", ltf="M5")
        bull = [z for z in zones if z.kind == "htf_fvg" and z.side == "bullish"]
        z = bull[0]
        assert z.invalidated is True
        # Fill on the M15 bar that dips to 99 (17:00), not an arbitrary M1 horizon.
        assert z.end_ts == pd.Timestamp("2025-01-02 17:00", tz="Etc/GMT-3")
        assert (z.end_ts - z.start_ts) == pd.Timedelta(minutes=45)

    def test_causal_agent_zones_still_delayed(self) -> None:
        """Agent ``build_fvg_zones`` remains on causal M1 edge (next HTF open)."""
        bars = self._m15_bullish_gap_m1()
        signals = detect_htf_fvg(bars, htf="M15")
        causal = build_fvg_zones(bars, signals, max_zone_bars=50)
        bull = [z for z in causal if z.side == "bullish"]
        assert bull
        # Causal start is after the forming HTF closes + shift → 16:45.
        assert bull[0].start_ts == pd.Timestamp("2025-01-02 16:45", tz="Etc/GMT-3")
