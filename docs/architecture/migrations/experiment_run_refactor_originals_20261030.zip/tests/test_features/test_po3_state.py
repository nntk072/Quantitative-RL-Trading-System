"""Tests for PO3 manipulation/distribution state and IFVG zones (Agent.md §6, §7)."""

from __future__ import annotations

from typing import cast

import numpy as np
import pandas as pd
import pytest
from omegaconf import DictConfig, OmegaConf

from features import build_features
from features.po3.fvg import build_fvg_zone_features
from features.po3.fvg_detection import FVGConfig
from features.po3.ifvg_state import build_po3_ifvg_state
from features.po3.po3_phase_state import (
    align_ifvg_zone_timeframes,
    build_distribution_after_ifvg,
    build_ifvg_zone_features,
    build_po3_state,
)

N = 20


def make_bars(rows: list[tuple[float, float, float]]) -> pd.DataFrame:
    """Build an OHLC frame from (high, low, close) triples on a 1-min index."""
    idx = pd.date_range("2024-01-02 01:05", periods=len(rows), freq="1min")
    high = [r[0] for r in rows]
    low = [r[1] for r in rows]
    close = [r[2] for r in rows]
    open_ = [close[0]] + close[:-1]
    return pd.DataFrame({"open": open_, "high": high, "low": low, "close": close}, index=idx)


def empty_sweeps(index: pd.Index) -> pd.DataFrame:
    return pd.DataFrame(
        0.0,
        index=index,
        columns=[
            "sweep_high",
            "sweep_low",
            "sweep_high_level",
            "sweep_low_level",
            "sweep_high_reclaimed",
            "sweep_low_reclaimed",
            "sweep_high_age",
            "sweep_low_age",
        ],
    )


def test_configured_ifvg_timeframes_align_and_merge_causally() -> None:
    """Configured M3 and higher IFVG confirmations join M1 causally."""
    index = pd.date_range("2025-01-06 00:00", periods=130, freq="1min", tz="UTC")
    close = np.full(len(index), 100.0)
    bars = pd.DataFrame(
        {"open": close, "high": close + 1.0, "low": close - 1.0, "close": close}, index=index
    )
    primary_zones = build_ifvg_zone_features(bars)
    source_specs = {
        "M3": ("3min", 3),
        "M5": ("5min", 5),
        "M10": ("10min", 10),
        "M15": ("15min", 15),
        "H1": ("1h", 60),
    }
    higher: dict[str, tuple[pd.DataFrame, pd.DataFrame]] = {}
    for tf, (frequency, _) in source_specs.items():
        tf_index = pd.date_range(index[0], periods=4, freq=frequency, tz="UTC")
        tf_bars = pd.DataFrame(
            {"open": 100.0, "high": 101.0, "low": 99.0, "close": 100.0}, index=tf_index
        )
        zones = pd.DataFrame(0.0, index=tf_index, columns=primary_zones.columns)
        zones["ifvg_bull_low"] = 99.5
        zones["ifvg_bull_high"] = 100.5
        zones["ifvg_bull_fvg_origin_bar"] = 0.0
        higher[tf] = (tf_bars, zones)

    # Two M15 confirmations create one same-side collision with M5 at minute 15.
    higher["M5"][1].loc[higher["M5"][0].index[[0, 2]], "ifvg_bull_confirmed"] = 1.0
    higher["M5"][1].loc[higher["M5"][0].index[0], "ifvg_retest_bull"] = 1.0
    higher["M15"][1].loc[higher["M15"][0].index[[0, 1]], "ifvg_bull_confirmed"] = 1.0
    higher["H1"][1].loc[higher["H1"][0].index[0], "ifvg_bull_confirmed"] = 1.0
    higher["M10"][1].loc[higher["M10"][0].index[0], "ifvg_bull_confirmed"] = 1.0
    higher["M3"][1].loc[higher["M3"][0].index[0], "ifvg_bull_confirmed"] = 1.0
    merged, visible = align_ifvg_zone_timeframes(bars, primary_zones, higher)

    event_rows = np.asarray([3, 5, 10, 15, 30, 60], dtype=int)
    assert merged["ifvg_bull_confirmed"].iloc[event_rows].tolist() == [1.0] * 6
    assert merged["_ifvg_bull_confirmation_tf_code"].iloc[event_rows].tolist() == [
        3.0,
        5.0,
        10.0,
        5.0,
        15.0,
        60.0,
    ]
    assert merged["ifvg_bull_confirmed"].iloc[:3].sum() == 0.0
    assert merged["ifvg_bull_fvg_origin_bar"].iloc[event_rows].tolist() == [0.0] * 6
    assert merged["ifvg_bull_low"].iloc[event_rows].tolist() == [99.5] * 6
    assert {
        "M3_ifvg_bull_active",
        "M5_ifvg_bull_active",
        "M10_ifvg_bull_active",
        "M15_ifvg_bull_active",
        "H1_ifvg_bull_active",
    } <= set(map(str, visible.columns))
    assert visible["M5_ifvg_retest_bull"].iloc[5] == 1.0
    assert visible["M5_ifvg_retest_bull"].iloc[6:10].sum() == 0.0

    sweeps = empty_sweeps(index)
    sweeps.loc[index[0], ["sweep_low", "sweep_low_level"]] = [1.0, 99.0]
    state = build_po3_ifvg_state(bars, sweeps, merged)
    assert state["po3_ifvg_confirmed"].iloc[3] == 1.0
    assert state["po3_ifvg_confirmation_tf_code"].iloc[3] == 3.0
    assert state["po3_ifvg_low"].iloc[3] == pytest.approx(99.5)


def flat_asian(index: pd.Index, high: float, low: float) -> pd.DataFrame:
    return pd.DataFrame({"asian_high": high, "asian_low": low}, index=index)


LONG_PATH = [(101.5, 100.5, 101.0)] * 10 + [
    (100.8, 98.0, 100.0),  # bar 10: sweep low wick
    (101.0, 97.5, 100.2),  # bar 11: manipulation low 97.5
    (101.2, 100.0, 100.8),  # bar 12
    (101.6, 100.8, 101.4),  # bar 13: close 101.4 above manip high -> end
    (102.0, 101.2, 101.8),  # bar 14: distribution
    (102.2, 101.4, 102.0),
]


def long_sweeps(index: pd.Index) -> pd.DataFrame:
    sw = empty_sweeps(index)
    sw.loc[index[10], "sweep_low"] = 1.0
    sw.loc[index[10], "sweep_low_level"] = 98.5
    return sw


class TestPO3StateLong:
    def test_manipulation_starts_on_sweep(self) -> None:
        bars = make_bars(LONG_PATH)
        state = build_po3_state(bars, long_sweeps(bars.index), flat_asian(bars.index, 103.0, 99.0))

        assert state["po3_manipulation_active"].iloc[10] == 1
        assert state["po3_manipulation_low"].iloc[10] == pytest.approx(98.0)
        assert state["po3_manipulation_active"].iloc[:10].sum() == 0

    def test_manipulation_end_and_distribution(self) -> None:
        bars = make_bars(LONG_PATH)
        state = build_po3_state(bars, long_sweeps(bars.index), flat_asian(bars.index, 103.0, 99.0))

        # Bar 13 closes above the manipulation-leg high -> manipulation ends.
        assert state["po3_manipulation_end"].iloc[13] == 1
        assert state["po3_manipulation_end"].iloc[:13].sum() == 0
        assert state["po3_distribution"].iloc[13] == 1
        assert state["po3_distribution_direction"].iloc[13] == 1
        assert state["po3_manipulation_active"].iloc[13] == 0

    def test_extremes_persist_for_sl(self) -> None:
        bars = make_bars(LONG_PATH)
        state = build_po3_state(bars, long_sweeps(bars.index), flat_asian(bars.index, 103.0, 99.0))

        tail = state.iloc[13:]
        assert np.allclose(tail["po3_manipulation_low"].to_numpy(dtype=float), 97.5)
        assert (tail["po3_distribution"] == 1).all()
        assert (tail["po3_distribution_direction"] == 1).all()


class TestPO3StateShort:
    def test_short_manipulation_end_and_distribution(self) -> None:
        bars = make_bars(LONG_PATH)
        sw = empty_sweeps(bars.index)
        sw.loc[bars.index[10], "sweep_high"] = 1.0
        sw.loc[bars.index[10], "sweep_high_level"] = 101.8
        # Sweep-high wick to 102.5, base holds above 100.0, then breakdown.
        bars.loc[bars.index[10]] = {"open": 101.0, "high": 102.5, "low": 100.5, "close": 101.0}
        bars.loc[bars.index[11]] = {"open": 101.0, "high": 101.2, "low": 100.0, "close": 100.6}
        bars.loc[bars.index[12]] = {"open": 100.4, "high": 100.4, "low": 99.0, "close": 99.5}
        state = build_po3_state(bars, sw, flat_asian(bars.index, 103.0, 99.0))

        assert state["po3_manipulation_active"].iloc[10] == 1
        assert state["po3_manipulation_high"].iloc[11] == pytest.approx(102.5)
        assert state["po3_manipulation_end"].iloc[12] == 1
        assert state["po3_distribution_direction"].iloc[12] == -1
        tail = state.iloc[12:]
        assert np.allclose(tail["po3_manipulation_high"].to_numpy(dtype=float), 102.5)


class TestPO3StateGuards:
    def test_no_state_without_asian_context(self) -> None:
        bars = make_bars(LONG_PATH)
        no_asian = pd.DataFrame({"asian_high": np.nan, "asian_low": np.nan}, index=bars.index)
        state = build_po3_state(bars, long_sweeps(bars.index), no_asian)

        assert state["po3_manipulation_active"].sum() == 0
        assert state["po3_distribution"].sum() == 0

    def test_opposite_sweep_flips_direction(self) -> None:
        bars = make_bars(LONG_PATH)
        sw = long_sweeps(bars.index)
        sw.loc[bars.index[14], "sweep_high"] = 1.0
        sw.loc[bars.index[14], "sweep_high_level"] = 102.5
        state = build_po3_state(bars, sw, flat_asian(bars.index, 103.0, 99.0))

        # A fresh opposite sweep re-arms a short manipulation setup.
        assert state["po3_manipulation_active"].iloc[14] == 1
        assert state["po3_distribution_direction"].iloc[14] == 0

    def test_causality(self) -> None:
        bars = make_bars(LONG_PATH)
        sw = long_sweeps(bars.index)
        asian = flat_asian(bars.index, 103.0, 99.0)
        full = build_po3_state(bars, sw, asian)
        short = build_po3_state(bars.iloc[:12], sw.iloc[:12], asian.iloc[:12])
        pd.testing.assert_frame_equal(full.iloc[:12], short, check_freq=False)


class TestIFVGZones:
    def build_frame(self) -> pd.DataFrame:
        # Single bullish FVG confirmed after a later close beyond the passing wick.
        rows = [
            (100.0, 99.0, 99.5),
            (100.5, 99.5, 100.0),
            (101.2, 99.8, 100.0),
            (102.5, 100.9, 102.0),  # FVG zone 100.5-100.9; wick passes through
            (103.2, 100.6, 102.8),  # confirms beyond the prior passing wick
            (103.5, 102.0, 103.0),
            (103.2, 102.0, 102.5),
            (103.0, 101.5, 101.8),
            (103.0, 100.6, 100.8),  # retest: close inside the zone
            (102.5, 101.0, 101.5),
        ]
        return make_bars(rows)

    def test_bullish_zone_active_and_in_zone(self) -> None:
        bars = self.build_frame()
        zones = build_ifvg_zone_features(bars, max_age_bars=50)

        confirmed = zones["ifvg_bull_active"] == 1
        assert confirmed.any()
        start = int(np.argmax(confirmed.to_numpy()))
        assert zones["ifvg_bull_confirmed"].iloc[start] == 1
        assert zones["ifvg_bull_age"].iloc[start] == 0
        assert zones["ifvg_bull_age"].iloc[start + 1] == 1
        zone_low = zones["ifvg_bull_low"].iloc[start]
        zone_high = zones["ifvg_bull_high"].iloc[start]
        assert zone_low == pytest.approx(100.5)
        assert zone_high == pytest.approx(100.9)
        # Retest bar closes inside the zone bounds.
        assert zones["price_in_ifvg_bull"].iloc[8] == 1
        assert zones["ifvg_bull_distance_atr"].iloc[start] >= 0

    def test_zone_expires(self) -> None:
        bars = self.build_frame()
        zones = build_ifvg_zone_features(bars, max_age_bars=2)

        confirmed = zones["ifvg_bull_active"] == 1
        start = int(np.argmax(confirmed.to_numpy()))
        # Lifetime is start <= t < start + max_age_bars.
        assert zones["ifvg_bull_active"].iloc[start + 1] == 1
        assert zones["ifvg_bull_active"].iloc[start + 2] == 0

    def test_bearish_zone(self) -> None:
        # Bearish FVG, followed by a close beyond the passing wick and later retest.
        rows = [
            (101.0, 100.0, 100.5),
            (100.5, 99.5, 100.0),
            (100.2, 99.0, 99.5),
            (99.0, 97.5, 98.0),  # bearish FVG zone 99.0-99.5; wick passes through
            (100.0, 96.0, 98.5),  # passes the zone; next close must clear its wick
            (100.0, 95.0, 95.5),  # confirms below the passing wick and 10% buffer
            (98.8, 95.8, 96.2),  # leaves the zone without creating a newer gap
            (98.9, 95.5, 96.0),
            (99.5, 99.0, 99.2),  # close inside the active zone
            (99.3, 99.0, 99.1),
        ]
        bars = make_bars(rows)
        zones = build_ifvg_zone_features(bars, max_age_bars=50)

        confirmed = zones["ifvg_bear_active"] == 1
        assert confirmed.any()
        start = int(np.argmax(confirmed.to_numpy()))
        assert zones["ifvg_bear_low"].iloc[start] == pytest.approx(99.0)
        assert zones["ifvg_bear_high"].iloc[start] == pytest.approx(99.5)
        assert zones["price_in_ifvg_bear"].iloc[8] == 1

    def test_fill_ends_the_zone(self) -> None:
        bars = self.build_frame()
        bars.loc[bars.index[6], "low"] = 100.4
        # A wick through is not invalidation; the next completed body close is.
        bars.loc[bars.index[7], "low"] = 99.8
        bars.loc[bars.index[7], "close"] = 100.0
        zones = build_ifvg_zone_features(bars, max_age_bars=50)
        assert zones["ifvg_bull_active"].iloc[6] == 1
        assert zones["ifvg_bull_active"].iloc[7] == 0
        assert zones["price_in_ifvg_bull"].iloc[8] == 0
        assert zones["ifvg_retest_bull"].iloc[8] == 0
        assert zones["ifvg_bull_distance_atr"].iloc[8] == 5.0

    def test_holding_retest_is_not_a_close_inside_the_gap(self) -> None:
        bars = self.build_frame()
        # Bar 7 is entirely above the zone. Bar 8 tags the high and closes back above it.
        bars.loc[bars.index[7], "low"] = 101.2
        bars.loc[bars.index[7], "high"] = 103.0
        bars.loc[bars.index[7], "close"] = 102.0
        bars.loc[bars.index[8], "low"] = 100.7
        bars.loc[bars.index[8], "high"] = 102.0
        bars.loc[bars.index[8], "close"] = 101.1
        bars.loc[bars.index[9], "low"] = 100.8
        bars.loc[bars.index[9], "high"] = 102.5
        bars.loc[bars.index[9], "close"] = 102.2
        zones = build_ifvg_zone_features(bars, max_age_bars=50)
        assert zones["price_in_ifvg_bull"].iloc[8] == 0
        assert zones["ifvg_retest_bull"].iloc[8] == 0
        assert zones["ifvg_retest_bull"].iloc[9] == 1
        assert zones["ifvg_bull_origin"].iloc[8] == pytest.approx(99.5)

    def test_retest_accepts_a_touch_deep_inside_the_zone(self) -> None:
        bars = self.build_frame()
        bars.loc[bars.index[7], "low"] = 101.2
        bars.loc[bars.index[7], "high"] = 103.0
        bars.loc[bars.index[7], "close"] = 102.0
        bars.loc[bars.index[8], "low"] = 100.6
        bars.loc[bars.index[8], "high"] = 102.0
        bars.loc[bars.index[8], "close"] = 100.7
        bars.loc[bars.index[9], "low"] = 100.8
        bars.loc[bars.index[9], "high"] = 102.5
        bars.loc[bars.index[9], "close"] = 102.2

        zones = build_ifvg_zone_features(bars, max_age_bars=50)

        assert zones["ifvg_retest_bull"].iloc[8] == 0
        assert zones["ifvg_retest_bull"].iloc[9] == 1

    def test_causality(self) -> None:
        bars = self.build_frame()
        full = build_ifvg_zone_features(bars, max_age_bars=50)
        short = build_ifvg_zone_features(bars.iloc[:8], max_age_bars=50)
        pd.testing.assert_frame_equal(full.iloc[:8], short, check_freq=False)

    def test_fvg_reaction_buffer_is_optional(self) -> None:
        bars = make_bars(
            [
                (100.0, 99.0, 99.5),
                (100.5, 99.5, 100.0),
                (101.2, 99.8, 100.0),
                (102.5, 100.9, 102.0),
                (103.0, 101.2, 102.0),
                (100.91, 100.6, 100.8),
                (101.0, 100.91, 100.92),
            ]
        )
        bars.loc[bars.index[5], "open"] = 100.8
        bars.loc[bars.index[6], "open"] = 100.91
        enabled = build_fvg_zone_features(
            bars,
            fvg_config=FVGConfig(reaction_buffer_fraction=0.1, reaction_buffer_enabled=True),
        )
        disabled = build_fvg_zone_features(
            bars,
            fvg_config=FVGConfig(reaction_buffer_fraction=0.1, reaction_buffer_enabled=False),
        )
        lower = build_fvg_zone_features(
            bars,
            fvg_config=FVGConfig(reaction_buffer_fraction=0.02, reaction_buffer_enabled=True),
        )

        assert enabled["fvg_retest_bull"].iloc[6] == 0
        assert disabled["fvg_retest_bull"].iloc[6] == 1
        assert lower["fvg_retest_bull"].iloc[6] == 1


class TestBuildFeaturesIntegration:
    """The include_strategy_state block adds exactly its own columns (§8)."""

    STRATEGY_COLUMNS = [
        "sweep_high",
        "sweep_low",
        "sweep_low_level",
        "po3_manipulation_low",
        "po3_manipulation_high",
        "po3_manipulation_end",
        "po3_distribution",
        "po3_distribution_direction",
        "ifvg_bull_active",
        "ifvg_bear_active",
        "asian_range",
        "price_to_asian_high_atr",
        "price_to_asian_low_atr",
        "manipulation_low_distance_atr",
        "manipulation_high_distance_atr",
    ]

    def _cfg(self, flag: bool) -> DictConfig:
        base = cast(DictConfig, OmegaConf.load("config/base/default.yaml"))
        cfg = cast(DictConfig, OmegaConf.merge(base, OmegaConf.create({"features": {}})))
        cfg.features.include_strategy_state = flag
        cfg.features.htf_timeframes = []
        cfg.features.zscore_window = 20
        return cfg

    def test_strategy_block_added_when_enabled(self) -> None:
        bars = make_bars(LONG_PATH)
        feat = build_features(bars, cfg=self._cfg(True))
        for col in self.STRATEGY_COLUMNS:
            assert col in feat.columns, f"missing strategy column: {col}"
        # Distance features are finite where the underlying levels exist.
        assert feat["price_to_asian_low_atr"].notna().any()

    def test_baseline_schema_unchanged_when_disabled(self) -> None:
        bars = make_bars(LONG_PATH)
        feat = build_features(bars, cfg=self._cfg(False))
        for col in self.STRATEGY_COLUMNS:
            assert col not in feat.columns


def test_distribution_arms_the_bar_after_the_opposing_gap_fails() -> None:
    """Confirmation during the sell-side sweep arms the later long bars."""
    dist = np.array([0, 0, 0, 1, 1, 1], dtype=float)
    manip_on = np.array([0, 1, 1, 0, 0, 0], dtype=float)
    manip_dir = np.array([0, -1, -1, -1, -1, -1], dtype=float)
    bull = np.array([0, 0, 1, 0, 0, 0], dtype=float)
    bear = np.zeros(6)
    out = build_distribution_after_ifvg(dist, manip_on, manip_dir, bull, bear)
    assert out.tolist() == [0, 0, 0, 1, 1, 1]

    on_the_open = bull.copy()
    on_the_open[2] = 0
    on_the_open[3] = 1
    opened = build_distribution_after_ifvg(dist, manip_on, manip_dir, on_the_open, bear)
    assert opened.tolist() == [0, 0, 0, 0, 1, 1]

    flipped = dist.copy()
    flipped[4] = -1
    flipped[5] = -1
    nxt = build_distribution_after_ifvg(flipped, manip_on, manip_dir, bull, bear)
    assert nxt[4] == 0
    assert nxt[5] == 0
