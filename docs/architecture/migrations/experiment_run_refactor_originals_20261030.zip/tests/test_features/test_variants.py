"""Chain B tests: agent-variant feature blocks (PO3 phase, FVG zones).

The base multi-TF feature matrix (Chain A) must be unchanged when the
variant flags are off; each flag adds exactly its own block. FVG zone
features are validated against a hand-crafted bullish FVG so zone
activity windows are deterministic.
"""

from __future__ import annotations

from typing import Any, cast

import numpy as np
import pandas as pd
import pytest
from omegaconf import DictConfig, OmegaConf

from features import (
    build_fvg_zone_features,
    build_po3_phase_features,
)


@pytest.fixture
def fvg_bars() -> pd.DataFrame:
    """Bars with a guaranteed bullish FVG: bar1.high < bar3.low.

    Downtrend into bar1, then a sharp up-move leaving a 3-bar imbalance.
    After the gap, price re-enters the zone (stays inside, no fill).
    """
    n = 40
    idx = pd.date_range("2025-01-06 17:00", periods=n, freq="1min", tz="Etc/GMT-3")
    close = np.full(n, 100.0)
    # gentle downtrend bars 0..9
    close[:10] = np.linspace(101.0, 100.0, 10)
    # up-leg bars 10..13 leaving a gap between bar11.high and bar13.low
    close[10] = 100.6
    close[11] = 100.4  # bar1 of the FVG triplet (highest 'high' anchor below)
    close[12] = 102.0
    close[13] = 103.2  # bar3: low must exceed bar11's high
    close[14:] = 102.8  # drift back toward the zone, stay above gap low
    df = pd.DataFrame(
        {
            "open": np.roll(close, 1),
            "high": close + 0.05,
            "low": close - 0.05,
            "close": close,
            "volume": np.full(n, 1000.0),
        },
        index=idx,
    )
    df.loc[df.index[11], "high"] = 100.8  # bar1 high (gap bottom)
    df.loc[df.index[13], "low"] = 101.5  # bar3 low (gap top)
    return df


def test_po3_phase_known_timestamps():
    idx = pd.date_range("2025-01-06 16:30", periods=395, freq="1min", tz="Etc/GMT-3")
    feats = build_po3_phase_features(idx, session_start="16:30", session_end="23:00")
    # first bar = session open → accumulation (phase 0), progress 0
    assert feats["po3_phase"].iloc[0] == 0
    assert feats["session_progress"].iloc[0] == pytest.approx(0.0)
    # monotonic progress
    assert feats["session_progress"].is_monotonic_increasing
    # 19:30 → 180/390 ≈ 0.46 → manipulation (phase 1)
    assert feats.loc[pd.Timestamp("2025-01-06 19:30", tz="Etc/GMT-3"), "po3_phase"] == 1
    # 22:30 → 360/390 ≈ 0.92 → distribution (phase 2)
    assert feats.loc[pd.Timestamp("2025-01-06 22:30", tz="Etc/GMT-3"), "po3_phase"] == 2


def test_po3_phase_outside_session_nan():
    idx = pd.date_range("2025-01-06 10:00", periods=5, freq="1min", tz="Etc/GMT-3")
    feats = build_po3_phase_features(idx, session_start="16:30", session_end="23:00")
    assert feats["po3_phase"].isna().all()
    assert (feats["session_progress"] == 0.0).all()


def test_fvg_zone_features_in_zone(fvg_bars):
    feats = build_fvg_zone_features(fvg_bars)
    # a bullish zone must exist (up-leg leaves a 3-bar imbalance)
    assert feats["fvg_in_bull"].sum() > 0
    # inside a zone: distance < cap on that side
    assert (feats.loc[feats["fvg_in_bull"] == 1.0, "fvg_bull_dist"] < 5.0).all()
    # before any zone can exist (first 2 bars of the sample): cap on both sides
    assert (feats.iloc[:2][["fvg_bull_dist", "fvg_bear_dist"]] == 5.0).all().all()
    # distances never exceed the cap
    assert feats["fvg_bull_dist"].max() <= 5.0 and feats["fvg_bear_dist"].max() <= 5.0


def test_fvg_retest_holds_and_a_fill_ends_the_zone():
    idx = pd.date_range("2025-01-06 17:00", periods=8, freq="1min", tz="Etc/GMT-3")
    # Candle 1 is bar 1 (low 99). The gap is 100-101. Bar 5 retests and holds;
    # bar 6 confirms above the retest candle despite a wick through the zone.
    # Bar 7 body-closes through the distal edge and invalidates the zone.
    rows = [
        (100.0, 98.0, 99.0),
        (100.0, 99.0, 99.5),
        (103.0, 99.8, 102.0),
        (104.0, 101.0, 103.0),
        (105.0, 102.0, 104.0),
        (103.0, 100.4, 101.2),
        (103.3, 99.5, 103.2),
        (103.3, 99.5, 99.9),
    ]
    bars = pd.DataFrame(
        {
            "open": [99.0, 99.0, 99.5, 102.0, 103.0, 102.5, 101.2, 103.2],
            "high": [r[0] for r in rows],
            "low": [r[1] for r in rows],
            "close": [r[2] for r in rows],
        },
        index=idx,
    )
    feats = build_fvg_zone_features(bars)
    assert feats["fvg_retest_bull"].iloc[6] == 1.0
    assert feats["fvg_in_bull"].iloc[5] == 0.0
    assert feats["fvg_bull_low"].iloc[6] == pytest.approx(100.0)
    assert feats["fvg_bull_origin"].iloc[6] == pytest.approx(99.0)
    assert feats["fvg_bull_active"].iloc[6] == 1.0
    assert feats["fvg_retest_bull"].iloc[7] == 0.0
    assert feats["fvg_bull_active"].iloc[7] == 0.0
    assert feats["fvg_retest_bull"].iloc[7] == 0.0


def test_fvg_zone_features_causal(fvg_bars):
    """Feature values before the gap formation must not depend on later bars."""
    full = build_fvg_zone_features(fvg_bars)
    trunc = build_fvg_zone_features(fvg_bars.iloc[:25])
    overlap = trunc.index[:20]
    pd.testing.assert_frame_equal(full.loc[overlap], trunc.loc[overlap])


def _base_cfg() -> dict[str, Any]:
    return {
        "features": {
            "ema_periods": [9],
            "macd_fast": 12,
            "macd_slow": 26,
            "macd_signal": 9,
            "rsi_period": 14,
            "atr_period": 14,
            "adx_period": 14,
            "bb_period": 20,
            "bb_std": 2.0,
            "stoch_k": 14,
            "stoch_d": 3,
            "return_horizons": [1],
            "realized_vol_period": 20,
            "smt_swing_period": 5,
            "smt_corr_window": 20,
            "zscore_window": 100,
            "htf_timeframes": ["M5"],
        }
    }


def test_variant_flags_additive(m1_bars):
    from features import build_features

    cfg_base = OmegaConf.create(_base_cfg())
    base = build_features(m1_bars, cfg=cfg_base)

    cfg_po3 = OmegaConf.merge(cfg_base, OmegaConf.create({"features": {"include_po3": True}}))
    po3 = build_features(m1_bars, cfg=cast(DictConfig, cfg_po3))
    assert {"po3_phase", "session_progress"} <= set(map(str, po3.columns))
    assert set(map(str, base.columns)) < set(map(str, po3.columns))

    cfg_fvg = OmegaConf.merge(cfg_base, OmegaConf.create({"features": {"include_fvg_ifvg": True}}))
    fvg = build_features(m1_bars, cfg=cast(DictConfig, cfg_fvg))
    assert any(str(c).startswith("M5_fvg_") for c in fvg.columns)
    # FVG full-ladder fix (plan §4.5): the M1 leg is included alongside HTFs.
    assert any(str(c).startswith("M1_fvg_") for c in fvg.columns)
    assert set(map(str, base.columns)) < set(map(str, fvg.columns))


def _mtf_cfg(**blocks: Any) -> DictConfig:
    """Merge MTF opt-in blocks + flat feature flags (plan §5) over the base."""
    return cast(
        DictConfig,
        OmegaConf.merge(OmegaConf.create(_base_cfg()), OmegaConf.create({"features": blocks})),
    )


def _mtf_secondary(m1_bars: pd.DataFrame) -> pd.DataFrame:
    """Correlated secondary symbol bars for the SMT MTF block."""
    sec = m1_bars.copy()
    rng = np.random.default_rng(7)
    sec["close"] = sec["close"] * 0.5 + rng.normal(0, 1, len(sec))
    sec["high"] = sec["high"] * 0.5
    sec["low"] = sec["low"] * 0.5
    return sec


def test_mtf_blocks_off_by_default(m1_bars):
    """New MTF blocks must not change the base matrix unless enabled (plan §5)."""
    from features import build_features

    base = build_features(
        m1_bars, secondary=_mtf_secondary(m1_bars), cfg=OmegaConf.create(_base_cfg())
    )
    for col in base.columns:
        assert not str(col).startswith(("M5_smt_", "M15_smt_", "H1_smt_"))
        assert not str(col).startswith(("M5_bos_", "M15_bos_", "H1_bos_"))
        assert not str(col).startswith(("M5_sweep_", "M15_sweep_", "H1_sweep_"))
        assert "_dist_to_swing_" not in str(col)


def test_smt_mtf_additive_and_causal(m1_bars):
    """SMT MTF (§4.1): per-TF divergence columns, causal under truncation."""
    from features import build_features

    sec = _mtf_secondary(m1_bars)
    base = build_features(m1_bars, secondary=sec, cfg=OmegaConf.create(_base_cfg()))
    cfg = _mtf_cfg(smt={"enabled": True, "timeframes": ["M5"]})
    mtf = build_features(m1_bars, secondary=sec, cfg=cfg)
    assert "M5_smt_bearish" in set(map(str, mtf.columns))
    assert set(map(str, base.columns)) < set(map(str, mtf.columns))

    trunc = build_features(m1_bars.iloc[:400], secondary=sec.iloc[:400], cfg=cfg)
    overlap = trunc.index[:300]
    cols = ["M5_smt_bearish", "M5_smt_bullish"]
    pd.testing.assert_frame_equal(mtf.loc[overlap, cols], trunc.loc[overlap, cols], rtol=1e-9)


def test_structure_bos_mtf_additive_and_causal(m1_bars):
    """Structure/BOS MTF (§4.2): TF swings + close-through BOS + ATR distances."""
    from features import build_features

    base = build_features(m1_bars, cfg=OmegaConf.create(_base_cfg()))
    timeframes = ["M5", "M10", "M15", "M30", "H1", "H4", "D1"]
    cfg = _mtf_cfg(structure={"enabled": True, "timeframes": timeframes})
    mtf = build_features(m1_bars, cfg=cfg)
    cols = set(map(str, mtf.columns))
    for tf in timeframes:
        assert {
            f"{tf}_last_swing_high",
            f"{tf}_last_swing_low",
            f"{tf}_bos_up",
            f"{tf}_bos_down",
        } <= cols
        assert {f"{tf}_dist_to_swing_high_atr", f"{tf}_dist_to_swing_low_atr"} <= cols
    assert set(map(str, base.columns)) < cols

    trunc = build_features(m1_bars.iloc[:400], cfg=cfg)
    overlap = trunc.index[:300]
    check = [
        column
        for tf in timeframes
        for column in (f"{tf}_last_swing_high", f"{tf}_bos_up", f"{tf}_dist_to_swing_high_atr")
    ]
    pd.testing.assert_frame_equal(mtf.loc[overlap, check], trunc.loc[overlap, check], rtol=1e-9)


def test_liquidity_sweep_mtf_additive_and_causal(m1_bars):
    """Sweep MTF (§4.3): true per-TF sweeps on resampled OHLC, causal."""
    from features import build_features

    base = build_features(m1_bars, cfg=OmegaConf.create(_base_cfg()))
    cfg = _mtf_cfg(liquidity={"enabled": True, "timeframes": ["M5", "M10"]})
    mtf = build_features(m1_bars, cfg=cfg)
    assert {"M5_sweep_high", "M5_sweep_low", "M10_sweep_high", "M10_sweep_low"} <= set(
        map(str, mtf.columns)
    )
    assert set(map(str, base.columns)) < set(map(str, mtf.columns))

    trunc = build_features(m1_bars.iloc[:400], cfg=cfg)
    overlap = trunc.index[:300]
    check = ["M5_sweep_high", "M5_sweep_low", "M10_sweep_high", "M10_sweep_low"]
    pd.testing.assert_frame_equal(mtf.loc[overlap, check], trunc.loc[overlap, check], rtol=1e-9)


def test_po3_state_mtf_behind_flag(m1_bars):
    """PO3 state MTF (§4.4): per-TF state machines, causal, off by default."""
    from features import build_features

    cfg_on = _mtf_cfg(
        include_strategy_state=True,
        po3_state_mtf={"enabled": True, "timeframes": ["M5", "M10"]},
    )
    mtf = build_features(m1_bars, cfg=cfg_on)
    assert "M5_po3_manipulation_active" in set(map(str, mtf.columns))
    assert "M10_po3_manipulation_active" in set(map(str, mtf.columns))

    trunc = build_features(m1_bars.iloc[:400], cfg=cfg_on)
    overlap = trunc.index[:300]
    check = [
        "M5_po3_manipulation_active",
        "M5_po3_distribution",
        "M10_po3_manipulation_active",
        "M10_po3_distribution",
    ]
    pd.testing.assert_frame_equal(mtf.loc[overlap, check], trunc.loc[overlap, check], rtol=1e-9)


def test_ifvg_mtf_behind_flag(m1_bars):
    """IFVG zones from M5/M15/H1 align causally and stay opt-in by default."""
    from features import build_features

    cfg_on = _mtf_cfg(
        include_strategy_state=True,
        po3_phase_mode="reclaim_then_ifvg",
        ifvg_mtf={"enabled": True, "timeframes": ["M5", "M10", "M15", "H1"]},
    )
    mtf = build_features(m1_bars, cfg=cfg_on)
    assert {f"{tf}_ifvg_bull_active" for tf in ("M5", "M10", "M15", "H1")} <= set(
        map(str, mtf.columns)
    )
    assert {
        "po3_ifvg_confirmation_tf_code",
        "ifvg_bull_confirmation_tf_code",
        "ifvg_bear_confirmation_tf_code",
    } <= set(map(str, mtf.columns))

    trunc = build_features(m1_bars.iloc[:400], cfg=cfg_on)
    overlap = trunc.index[:300]
    check = [
        f"{tf}_ifvg_{side}_active" for tf in ("M5", "M10", "M15", "H1") for side in ("bull", "bear")
    ]
    pd.testing.assert_frame_equal(mtf.loc[overlap, check], trunc.loc[overlap, check], rtol=1e-9)


def test_variant_config_files_merge():
    """The variant YAMLs enable their feature blocks over the native MTF defaults."""
    base = OmegaConf.load("config/base/default.yaml")
    variants = [
        ("config/features/technical_mtf.yaml", False, False),
        ("config/features/po3_mtf.yaml", True, False),
        ("config/features/fvg_ifvg_mtf.yaml", False, True),
    ]
    for fname, want_po3, want_fvg in variants:
        merged = OmegaConf.merge(base, OmegaConf.load(fname))
        assert merged.features.include_po3 is want_po3
        assert merged.features.include_fvg_ifvg is want_fvg
        assert list(merged.features.htf_timeframes) == [
            "M3",
            "M5",
            "M10",
            "M15",
            "M30",
            "H1",
            "H4",
            "D1",
        ]


def test_idea_overlays_enable_synchronized_mtf_ifvg():
    """The revised Idea variants consume native M3-D1 IFVGs on the M1 PO3 clock."""
    base = OmegaConf.load("config/base/default.yaml")
    expected_ids = {
        "config/2_po3_ifvg.yaml": "po3_confirmed_ifvg_htf_mtf_v1",
        "config/3_distribution.yaml": "distribution_prev_session_pd_mtf_v1",
    }
    for path, variant_id in expected_ids.items():
        merged = OmegaConf.merge(base, OmegaConf.load(path))
        assert list(merged.features.po3_reference_timeframes) == [
            "M3",
            "M5",
            "M10",
            "M15",
            "M30",
            "H1",
            "H4",
            "D1",
        ]
        assert merged.features.ifvg_mtf.enabled is True
        assert list(merged.features.ifvg_mtf.timeframes) == [
            "M3",
            "M5",
            "M10",
            "M15",
            "M30",
            "H1",
            "H4",
            "D1",
        ]
        assert merged.strategy.variant_id == variant_id


def test_po3_full_flag_additive(m1_bars):
    """include_po3_full=true adds the full PO3 entry-trigger columns on top of base."""
    from features import build_features

    cfg_base = OmegaConf.create(_base_cfg())
    base = build_features(m1_bars, cfg=cfg_base)

    cfg_full = OmegaConf.merge(cfg_base, OmegaConf.create({"features": {"include_po3_full": True}}))
    full = build_features(m1_bars, cfg=cast(DictConfig, cfg_full))

    assert set(map(str, base.columns)) < set(map(str, full.columns))
    for col in ["entry_long", "entry_short", "entry_trigger_type"]:
        assert col in set(map(str, full.columns))
    # matrix must stay homogeneous numeric (TradingEnv casts to float32)
    assert all(pd.api.types.is_numeric_dtype(full[c]) for c in full.columns)
    # entry signals are binary; trigger type is encoded 0..3
    assert set(full["entry_long"].dropna().unique()).issubset({0.0, 1.0})
    assert set(full["entry_short"].dropna().unique()).issubset({0.0, 1.0})
    assert set(full["entry_trigger_type"].dropna().unique()).issubset({0.0, 1.0, 2.0, 3.0})


def test_po3_full_no_lookahead_on_entries(m1_bars):
    """Entry signals at bar t must be unchanged by appending future bars.

    detect_po3_entries consumes only bars <= t when marking bar t (the M1
    loop uses each bar's own close once), so truncation must not alter past
    entry columns.
    """
    from features import build_features

    cfg = OmegaConf.merge(
        OmegaConf.create(_base_cfg()), OmegaConf.create({"features": {"include_po3_full": True}})
    )
    full = build_features(m1_bars, cfg=cast(DictConfig, cfg))
    trunc = build_features(m1_bars.iloc[:400], cfg=cast(DictConfig, cfg))

    overlap = trunc.index[:300]
    entry_cols = ["entry_long", "entry_short", "entry_trigger_type"]
    pd.testing.assert_frame_equal(
        full.loc[overlap, entry_cols],
        trunc.loc[overlap, entry_cols],
        rtol=1e-9,
    )


def test_combined_config_merges_all_blocks():
    """config/features/full_po3_mtf.yaml enables all three additive blocks."""
    base = OmegaConf.load("config/base/default.yaml")
    merged = OmegaConf.merge(base, OmegaConf.load("config/features/full_po3_mtf.yaml"))
    assert merged.features.include_po3 is True
    assert merged.features.include_fvg_ifvg is True
    assert merged.features.include_po3_full is True
    assert merged.features.po3_htf == "M15"
    assert merged.features.po3_ltf == "M1"
    assert list(merged.features.htf_timeframes) == [
        "M3",
        "M5",
        "M10",
        "M15",
        "M30",
        "H1",
        "H4",
        "D1",
    ]
