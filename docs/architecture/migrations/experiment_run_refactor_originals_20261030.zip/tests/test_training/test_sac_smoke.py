"""Smoke test for the SAC training path on TradingEnv.

The plan flagged that the SAC code path (``agent.py:112-131``) is
untested end-to-end: continuous action space + VAE + reward combo may
fail at runtime. SAC also has a long ``learning_starts`` warmup before
gradient steps fire, so we only need a few gradient updates to prove the
path is wired.

This test:
- Builds a continuous-action TradingEnv (``Box(-1, 1)``).
- Builds an SAC agent with the TCN encoder (default).
- Runs ``learn()`` for a small number of total_timesteps that exceeds
  ``learning_starts`` so at least one gradient step fires.
- Confirms the resulting policy can act on the env.
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd
import pytest
from omegaconf import OmegaConf

from learning.rl.agent import build_agent

pytestmark = pytest.mark.slow


def _make_bars(n: int = 600, seed: int = 7) -> pd.DataFrame:

    rng = np.random.default_rng(seed)
    idx = pd.date_range("2025-01-06 16:30", periods=n, freq="1min", tz="Etc/GMT-3")
    close = 20000.0 + np.cumsum(rng.normal(0, 2, n))
    return pd.DataFrame(
        {
            "open": close - rng.uniform(0, 1, n),
            "high": close + rng.uniform(0, 2, n),
            "low": close - rng.uniform(0, 2, n),
            "close": close,
            "tickvol": rng.integers(10, 200, n),
            "volume": rng.integers(1000, 5000, n),
            "vol": np.zeros(n, dtype=int),
            "spread": np.full(n, 0.6),
            "gap_flag": False,
            "session_id": 0,
        },
        index=idx,
    )


def _make_features(bars) -> pd.DataFrame:

    n = len(bars)
    rng = np.random.default_rng(7)
    return pd.DataFrame(
        {
            "london_high": 20500.0,
            "london_low": 19500.0,
            "asian_high": 20300.0,
            "asian_low": 19700.0,
            "volume_spike": rng.uniform(0.5, 2.5, n),
            "last_swing_high": np.nan,
            "last_swing_low": np.nan,
        },
        index=bars.index,
    )


@pytest.fixture
def sac_cfg() -> Any:
    """Minimal OmegaConf config for SAC smoke tests."""
    return OmegaConf.create(
        {
            "env": {"obs_window": 10},
            "sac": {
                "learning_rate": 3e-4,
                "buffer_size": 512,
                "batch_size": 32,
                "tau": 0.005,
                "gamma": 0.99,
                "train_freq": 1,
                "gradient_steps": 1,
                "ent_coef": "auto",
                "learning_starts": 64,
            },
        }
    )


@pytest.mark.parametrize("arch", ["tcn", "gru", "transformer"])
def test_sac_smoke_learns_a_few_steps(sac_cfg: Any, arch: str) -> None:
    """Build SAC on a continuous-action TradingEnv and confirm it learns."""
    pytest.importorskip("torch")
    pytest.importorskip("stable_baselines3")

    from simulation.environment.env import TradingEnv

    bars = _make_bars()
    features = _make_features(bars)
    env = TradingEnv(
        bars=bars,
        features=features,
        obs_window=10,
        continuous_actions=True,
        max_risk_frac=0.01,
        max_episode_steps=64,
    )

    model = build_agent(env, sac_cfg, arch=arch, algo="sac")

    from stable_baselines3 import SAC

    assert isinstance(model, SAC)

    model.learn(total_timesteps=256, progress_bar=False)

    obs, _ = env.reset(seed=0)
    raw, _ = model.predict(obs, deterministic=True)
    arr = np.asarray(raw).reshape(-1)
    assert arr.shape == (1,)
    assert -1.0 <= float(arr[0]) <= 1.0


def test_sac_training_callbacks_forward_update_arguments(sac_cfg: Any, tmp_path: Any) -> None:
    """Dashboard and flight-recorder wrappers preserve SAC's train signature."""
    pytest.importorskip("torch")
    pytest.importorskip("stable_baselines3")

    from simulation.environment.env import TradingEnv
    from training.callbacks.dashboard import TrainingDashboardCallback
    from training.callbacks.debug_trace import install_flight_recorder

    sac_cfg.sac.learning_starts = 4
    sac_cfg.sac.buffer_size = 64
    sac_cfg.sac.batch_size = 4
    bars = _make_bars(n=64)
    env = TradingEnv(
        bars=bars,
        features=_make_features(bars),
        obs_window=10,
        continuous_actions=True,
        max_risk_frac=0.01,
        max_episode_steps=64,
    )
    model = build_agent(env, sac_cfg, algo="sac")
    install_flight_recorder(model, tmp_path)
    dashboard = TrainingDashboardCallback(total_timesteps=16, eval_every=0, log_every=8)

    model.learn(total_timesteps=16, callback=dashboard, progress_bar=False)

    assert model.num_timesteps >= 16


def test_sac_rejects_discrete_action_space() -> None:
    """SAC must raise on a Discrete env — guards against silent misconfig."""
    pytest.importorskip("torch")
    pytest.importorskip("stable_baselines3")

    from simulation.environment.env import TradingEnv

    bars = _make_bars()
    features = _make_features(bars)
    env = TradingEnv(
        bars=bars,
        features=features,
        obs_window=10,
        continuous_actions=False,
    )

    cfg = OmegaConf.create(
        {
            "env": {"obs_window": 10},
            "sac": {"learning_starts": 10, "buffer_size": 64},
        }
    )
    with pytest.raises(ValueError, match="continuous"):
        build_agent(env, cfg, arch="tcn", algo="sac")


def test_sac_accepts_the_same_strategy_overlay_action_schema(sac_cfg: Any) -> None:
    pytest.importorskip("torch")
    pytest.importorskip("stable_baselines3")

    from simulation.environment.env import TradingEnv

    bars = _make_bars(n=128)
    features = _make_features(bars)
    ppo_contract = TradingEnv(
        bars=bars,
        features=features,
        obs_window=10,
        continuous_actions=False,
        strategy_actions=True,
        agent_direction_control=True,
        allow_agent_sl_mode=True,
        allow_agent_tp_mode=True,
        allow_multi_tp=True,
    )
    sac_env = TradingEnv(
        bars=bars,
        features=features,
        obs_window=10,
        continuous_actions=True,
        strategy_actions=True,
        agent_direction_control=True,
        allow_agent_sl_mode=True,
        allow_agent_tp_mode=True,
        allow_multi_tp=True,
    )
    assert ppo_contract.action_space.shape == sac_env.action_space.shape
    assert ppo_contract.action_schema.to_dict() == sac_env.action_schema.to_dict()

    model = build_agent(sac_env, sac_cfg, arch="tcn", algo="sac")
    from decisioning.adapters.sb3 import SB3DecisionProvider

    provider = SB3DecisionProvider(model, input_schema_version="test-observation-v1")
    assert model._action_schema == sac_env.action_schema.to_dict()
    assert provider.metadata.action_schema.coordinates == sac_env.action_schema.names
    observation, _ = sac_env.reset(seed=50)
    action, _ = model.predict(observation, deterministic=True)
    assert np.asarray(action).shape[-1] == sac_env.action_space.shape[0]
