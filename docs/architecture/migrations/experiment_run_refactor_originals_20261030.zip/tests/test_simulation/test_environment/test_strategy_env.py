"""Tests for strategy-mode environment (Agent.md §12, §27, §28, §29)."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest
from gymnasium.spaces import Box

from simulation.environment.env import TradingEnv
from trading.execution.costs import CostModel
from trading.strategies import PO3IFVGStrategy


def _bars(n: int = 120) -> pd.DataFrame:
    idx = pd.date_range("2020-01-01 01:05", periods=n, freq="1min")
    rng = np.random.default_rng(0)
    close = 100.0 + np.cumsum(rng.normal(0, 0.05, n))
    high = close + np.abs(rng.normal(0, 0.05, n))
    low = close - np.abs(rng.normal(0, 0.05, n))
    open_ = np.roll(close, 1)
    open_[0] = close[0]
    return pd.DataFrame(
        {
            "open": open_,
            "high": high,
            "low": low,
            "close": close,
            "volume": rng.integers(1000, 5000, n),
            "session_id": np.zeros(n, dtype=int),
        },
        index=idx,
    )


def _features(bars: pd.DataFrame) -> pd.DataFrame:
    n = len(bars)
    high = bars["high"].to_numpy()
    low = bars["low"].to_numpy()
    return pd.DataFrame(
        {
            "asian_high": np.full(n, float(high.max()) + 1.0),
            "asian_low": np.full(n, float(low.min()) - 1.0),
            "sweep_high": np.zeros(n),
            "sweep_low": np.ones(n),
            "po3_manipulation_low": np.full(n, 95.0),
            "po3_manipulation_high": np.full(n, 105.0),
            "po3_manipulation_end": np.ones(n),
            "po3_distribution": np.zeros(n),
            "po3_distribution_direction": np.zeros(n),
            "ifvg_bull_low": np.full(n, 98.0),
            "ifvg_bull_high": np.full(n, 99.0),
            "price_in_ifvg_bull": np.ones(n),
            "ifvg_retest_bull": np.ones(n),
            "ifvg_bear_low": np.zeros(n),
            "ifvg_bear_high": np.zeros(n),
            "ifvg_bull_active": np.ones(n),
            "ifvg_bear_active": np.zeros(n),
            "last_swing_high": np.full(n, float(high.max()) + 1.0),
            "last_swing_low": np.full(n, float(low.min()) - 1.0),
            "london_high": np.full(n, float(high.max()) + 2.0),
            "london_low": np.full(n, float(low.min()) - 2.0),
            "htf_day_bias": np.ones(n),
            "context_trade_direction": np.ones(n),
            "manip_reverses_htf": np.zeros(n),
            "atr_5": np.ones(n),
            "prev_day_high": np.full(n, 150.0),
            "prev_day_low": np.full(n, 50.0),
        },
        index=bars.index,
    )


class TestStrategyActionSpace:
    def test_5d_box_shape_and_bounds(self) -> None:
        bars = _bars()
        feats = _features(bars)
        env = TradingEnv(
            bars,
            feats,
            strategy_actions=True,
            strategy=PO3IFVGStrategy(enforce_gate=False),
            obs_window=10,
            allow_agent_sl_mode=False,
        )
        assert isinstance(env.action_space, Box)
        assert env.action_space.shape == (5,)
        np.testing.assert_array_equal(env.action_space.low, [-1.0, -1.0, -1.0, -1.0, -1.0])
        np.testing.assert_array_equal(env.action_space.high, [1.0, 1.0, 1.0, 1.0, 1.0])

    def test_action_contains_valid_5d(self) -> None:
        bars = _bars()
        feats = _features(bars)
        env = TradingEnv(
            bars,
            feats,
            strategy_actions=True,
            strategy=PO3IFVGStrategy(enforce_gate=False),
            obs_window=10,
            allow_agent_sl_mode=False,
        )
        action = np.array([0.0, 0.5, 0.7, 0.0, -1.0], dtype=np.float32)
        assert env.action_space.contains(action)

    def test_baseline_keeps_legacy_space(self) -> None:
        bars = _bars()
        feats = _features(bars)
        env = TradingEnv(bars, feats, strategy_actions=False, obs_window=10)
        # Baseline (strategy_actions=False) must NOT use the 5-D Box.
        assert env.action_space.shape != (5,)


class TestAdaptiveRiskSizing:
    def test_agent_can_choose_sub_250_dollar_risk(self) -> None:
        bars = _bars(n=30)
        feats = _features(bars)
        env = TradingEnv(
            bars,
            feats,
            strategy_actions=True,
            strategy=PO3IFVGStrategy(enforce_gate=False),
            obs_window=5,
            risk_frac_range=(0.0, 0.01),
            risk_floor=0.0005,
            rr_ratio_range=(2.0, 2.0),
            allow_agent_sl_mode=False,
        )
        env.reset()
        feat_row = env._feature_row_at(env.step_idx)
        action, risk_frac, _, _ = env._decode_action(
            np.array([0.9, 0.0, -0.8, 0.0, -1.0], dtype=np.float32), feat_row
        )

        assert action == 1
        assert risk_frac == pytest.approx(0.001)  # $100 at the $100k starting balance

    def test_dynamic_budget_includes_modeled_execution_costs(self) -> None:
        bars = _bars()
        env = TradingEnv(
            bars,
            _features(bars),
            strategy_actions=True,
            strategy=PO3IFVGStrategy(enforce_gate=False),
            initial_balance=100_000.0,
            risk_frac_range=(0.0, 0.01),
            max_loss_per_trade_usd=900.0,
            cost_model=CostModel(slippage_points=2.0, commission_per_lot=1.0),
        )

        lots = env._compute_lots_for(0.01, 100.0, 90.0)
        stop_risk = lots * 10.0 * env.contract_size
        reserve = env._modeled_execution_reserve_usd(lots)

        assert env._last_approved_risk_usd == pytest.approx(900.0)
        assert stop_risk + reserve == pytest.approx(900.0)


class TestPO3EntryModes:
    def test_confirmed_first_eligible_requires_confirmation_pulse(self) -> None:
        strategy = PO3IFVGStrategy(entry_mode="confirmed_first_eligible")
        assert (
            strategy.context_direction(pd.Series({"sweep_low": 1.0, "po3_ifvg_confirmed": 0.0}))
            == 0
        )
        assert (
            strategy.context_direction(
                pd.Series({"po3_ifvg_confirmed": 1.0, "po3_distribution_direction": 1.0})
            )
            == 1
        )
        assert (
            strategy.context_direction(
                pd.Series({"po3_ifvg_confirmed": 1.0, "po3_distribution_direction": -1.0})
            )
            == -1
        )

    def test_confirmed_retest_must_be_later_than_confirmation(self) -> None:
        strategy = PO3IFVGStrategy(entry_mode="confirmed_retest", require_price_retest=True)
        assert (
            strategy.context_direction(
                pd.Series(
                    {
                        "ifvg_bull_confirmed": 1.0,
                        "ifvg_retest_bull": 1.0,
                        "ifvg_bull_age": 0.0,
                        "po3_distribution_after_ifvg": 0.0,
                        "po3_distribution_direction": 1.0,
                    }
                )
            )
            == 0
        )
        assert (
            strategy.context_direction(
                pd.Series(
                    {
                        "ifvg_bull_confirmed": 0.0,
                        "ifvg_retest_bull": 1.0,
                        "ifvg_bull_age": 1.0,
                        "po3_distribution_after_ifvg": 1.0,
                        "po3_distribution_direction": 1.0,
                    }
                )
            )
            == 1
        )
        assert (
            strategy.context_direction(
                pd.Series(
                    {
                        "ifvg_retest_bull": 1.0,
                        "ifvg_bull_age": 6.0,
                        "po3_distribution_after_ifvg": 1.0,
                        "po3_distribution_direction": 1.0,
                    }
                )
            )
            == 0
        )

    def test_preconfirmation_mode_has_a_distinct_fvg_candidate_signal(self) -> None:
        strategy = PO3IFVGStrategy(
            entry_mode="preconfirmation_exploratory", require_price_retest=False
        )
        assert strategy.context_direction(pd.Series({"fvg_retest_bull": 1.0})) == 1
        assert strategy.context_direction(pd.Series({"po3_ifvg_confirmed": 1.0})) == 0

    def test_live_gap_can_qualify_without_retest_when_configured(self) -> None:
        strategy = PO3IFVGStrategy(require_price_retest=False)
        assert strategy.context_direction(pd.Series({"sweep_low": 1.0})) == 0
        assert strategy.context_direction(pd.Series({"fvg_bull_active": 1.0})) == 1
        assert strategy.context_direction(pd.Series({"ifvg_bear_active": 1.0})) == -1

    def test_new_entry_mode_rejects_conflicting_legacy_retest_flag(self) -> None:
        with pytest.raises(ValueError, match="conflicts"):
            PO3IFVGStrategy(
                entry_mode="confirmed_first_eligible",
                require_price_retest=True,
            )


class TestStrategyObservation:
    def test_raw_columns_excluded_from_seq(self) -> None:
        bars = _bars()
        feats = _features(bars)
        env = TradingEnv(
            bars,
            feats,
            strategy_actions=True,
            strategy=PO3IFVGStrategy(enforce_gate=False),
            obs_window=10,
        )
        obs = env.reset()[0]
        assert isinstance(obs, dict)
        assert "seq" in obs
        seq_width = int(obs["seq"].shape[1])
        assert obs["seq"].shape == (10, seq_width)
        assert env.observation_space.contains(obs)


class TestStrategyStructuralSL:
    def test_long_sl_at_manipulation_low(self) -> None:
        """Idea 1 long: SL = manipulation_low (exact mode, Agent.md §27)."""
        bars = _bars()
        feats = _features(bars)
        feats["po3_manipulation_low"] = np.full(len(bars), 95.0)
        feats["po3_manipulation_high"] = np.full(len(bars), 110.0)
        feats["last_swing_low"] = np.nan
        feats["asian_low"] = np.nan
        feats["london_low"] = np.nan
        feats["ifvg_bull_active"] = np.zeros(len(bars))
        env = TradingEnv(
            bars,
            feats,
            strategy_actions=True,
            strategy=PO3IFVGStrategy(enforce_gate=False),
            sl_buffer_pts=0.0,
            obs_window=10,
            initial_balance=100_000.0,
            risk_frac_range=(0.01, 0.01),
            rr_ratio_range=(2.0, 2.0),
            min_sl_points=0.0,
            min_sl_atr_mult=0.0,
            allow_agent_sl_mode=False,
        )
        env.reset()
        obs, _ = env.reset()
        filled = False
        for _ in range(len(bars) - 5):
            action = np.array([0.0, 0.0, 0.5, 0.0, -1.0], dtype=np.float32)
            obs, reward, done, truncated, info = env.step(action)
            if env.position is not None:
                # Exact mode (sl_buffer_pts=0.0): the stop sits exactly on the
                # structural level with no ATR widening applied on top.
                assert env.position.sl_price == pytest.approx(95.0)
                filled = True
                break
            if done or truncated:
                break
        assert filled, "expected a long position to be opened with SL=95.0"

    def test_invalid_geometry_rejected(self) -> None:
        """Manipulation_low >= entry must reject, not create a backwards SL."""
        bars = _bars()
        feats = _features(bars)
        feats["po3_manipulation_low"] = np.full(len(bars), 999.0)
        feats["last_swing_low"] = np.nan
        feats["asian_low"] = np.nan
        feats["london_low"] = np.nan
        feats["ifvg_bull_active"] = 0.0
        env = TradingEnv(
            bars,
            feats,
            strategy_actions=True,
            strategy=PO3IFVGStrategy(enforce_gate=False),
            sl_buffer_pts=0.0,
            obs_window=10,
            min_sl_points=0.0,
            min_sl_atr_mult=0.0,
            allow_agent_sl_mode=False,
        )
        env.reset()
        opened = False
        for _ in range(20):
            action = np.array([0.0, 0.0, 0.5, 0.0, 0.0], dtype=np.float32)
            obs, reward, done, truncated, info = env.step(action)
            if env.position is not None:
                opened = True
                break
        assert not opened, "invalid geometry must not open a position"
