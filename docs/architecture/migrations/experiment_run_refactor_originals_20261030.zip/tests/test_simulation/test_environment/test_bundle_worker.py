"""Bundle worker construction and payload tests."""

from __future__ import annotations

import pickle
import subprocess
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pytest
from tests.test_simulation.test_environment.test_trading_env_golden_traces import (
    _make_deterministic_bars,
    _make_features,
)


def test_worker_factory_matches_default_make_env(tmp_path: Path) -> None:
    """The compact spec factory retains the current training env defaults."""
    from configuration import load_config
    from simulation.environment.bundles import build_env_bundle
    from simulation.environment.spec import EnvSpec
    from simulation.environment.worker import make_bundle_env
    from trading.strategies import BaselineStrategy
    from training.setup.environments import make_env

    bars = _make_deterministic_bars(n=96)
    features = _make_features(bars)
    cfg = load_config()
    cfg.costs.use_tick_execution = False
    cfg.execution.randomized_fill_latency_ms = 0.0
    bundle_path = build_env_bundle(
        tmp_path,
        bars,
        features,
        cfg,
        raw_columns=list(BaselineStrategy().raw_columns),
        feature_config_hash="worker-default-v1",
        tickbook=None,
        pre_ny_by_date=None,
    )
    spec = EnvSpec.from_cfg(
        cfg,
        algo="ppo",
        reward="dsr",
        arch="tcn",
        bundle_dir=str(bundle_path),
    )
    left = make_env(bars, features, cfg, algo="ppo", reward="dsr", arch="tcn")
    right = make_bundle_env(spec)
    obs_left, _ = left.reset(seed=15)
    obs_right, _ = right.reset(seed=15)
    for key in obs_left:
        np.testing.assert_array_equal(obs_left[key], obs_right[key])
    for _ in range(60):
        left_step = left.step(0)
        right_step = right.step(0)
        for key in left_step[0]:
            np.testing.assert_array_equal(left_step[0][key], right_step[0][key])
        assert left_step[1:4] == right_step[1:4]
        assert left_step[4].keys() == right_step[4].keys()
        for key, left_value in left_step[4].items():
            right_value = right_step[4][key]
            if isinstance(left_value, (float, np.floating)) and np.isnan(left_value):
                assert isinstance(right_value, (float, np.floating)) and np.isnan(right_value)
            else:
                assert left_value == right_value


def test_bundle_worker_forwards_tick_execution_contract(monkeypatch, tmp_path: Path) -> None:
    """Shared-bundle workers receive the same strict tick fill settings."""
    from configuration import load_config
    from simulation.environment.env import TradingEnv
    from simulation.environment.spec import EnvSpec
    from simulation.environment.worker import make_bundle_env

    cfg = load_config()
    cfg.costs.use_tick_execution = True
    cfg.execution.fill_delay_ms = 0
    cfg.execution.randomized_fill_latency_ms = 30.0
    cfg.execution.max_tick_quote_wait_ms = 12_345
    spec = EnvSpec.from_cfg(
        cfg,
        algo="ppo",
        reward="dsr",
        arch="tcn",
        bundle_dir=str(tmp_path),
    )
    captured: dict[str, object] = {}
    expected = object()

    def capture_from_bundle(cls: Any, /, bundle_path: Any, **kwargs: Any) -> object:
        captured["bundle_path"] = bundle_path
        captured.update(kwargs)
        return expected

    monkeypatch.setattr(TradingEnv, "from_bundle", classmethod(capture_from_bundle))

    assert make_bundle_env(spec) is expected
    assert captured["tick_execution_required"] is True
    assert captured["fill_delay_ms"] == 0
    assert captured["randomized_fill_latency_ms"] == 30.0
    assert captured["max_tick_quote_wait_ms"] == 12_345


def test_evaluation_worker_disables_training_trailing_guardrails(tmp_path: Path) -> None:
    """Evaluation keeps daily/max-loss gates but disables trailing kill-switches."""
    from configuration import load_config
    from simulation.environment.bundles import build_env_bundle
    from simulation.environment.spec import EnvSpec
    from simulation.environment.worker import make_bundle_env
    from trading.strategies import BaselineStrategy

    bars = _make_deterministic_bars(n=96)
    features = _make_features(bars)
    cfg = load_config()
    cfg.ftmo.trailing_dd_limit = 0.07
    cfg.ftmo.soft_trailing_dd_limit = 0.02
    bundle_path = build_env_bundle(
        tmp_path,
        bars,
        features,
        cfg,
        raw_columns=list(BaselineStrategy().raw_columns),
        feature_config_hash="worker-evaluation-guardrails-v1",
        tickbook=None,
        pre_ny_by_date=None,
    )
    training_env = make_bundle_env(
        EnvSpec.from_cfg(
            cfg,
            algo="ppo",
            reward="dsr",
            arch="tcn",
            bundle_dir=str(bundle_path),
        )
    )
    evaluation_env = make_bundle_env(
        EnvSpec.from_cfg(
            cfg,
            algo="ppo",
            reward="dsr",
            arch="tcn",
            bundle_dir=str(bundle_path),
            episodic=False,
            evaluation=True,
        )
    )

    assert training_env.guardrails.trailing_dd_limit == 0.07
    assert training_env.guardrails.soft_trailing_dd_limit == 0.02
    assert evaluation_env.guardrails.trailing_dd_limit == 0.0
    assert evaluation_env.guardrails.soft_trailing_dd_limit == 0.0
    assert evaluation_env.guardrails.daily_loss_limit == training_env.guardrails.daily_loss_limit
    assert evaluation_env.guardrails.max_loss_limit == training_env.guardrails.max_loss_limit


def test_bundle_worker_forwards_execution_reference_configuration(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Bundle workers preserve the configured TP and session-reference semantics."""
    from configuration import load_config
    from simulation.environment.env import TradingEnv
    from simulation.environment.spec import EnvSpec
    from simulation.environment.worker import make_bundle_env

    schedule = tmp_path / "session_schedule.csv"
    schedule.write_text(
        "session_date,scheduled_ny_close_broker_time\n2025-06-02,20:00\n",
        encoding="utf-8",
    )
    cfg = load_config()
    cfg.data.session_schedule_file = str(schedule)
    cfg.risk.target_timeframes = ["M3", "M10", "H4", "D1"]
    cfg.risk.tp_mode = "trailing"
    cfg.risk.tp_reference = "structural"
    cfg.session.start = "16:15"
    spec = EnvSpec.from_cfg(
        cfg,
        algo="ppo",
        reward="dsr",
        arch="mtf_reasoning",
        bundle_dir=str(tmp_path / "bundle"),
    )
    captured: dict[str, Any] = {}
    expected = object()

    def capture_from_bundle(cls: Any, /, bundle_path: Any, **kwargs: Any) -> object:
        captured["bundle_path"] = bundle_path
        captured.update(kwargs)
        return expected

    monkeypatch.setattr(TradingEnv, "from_bundle", classmethod(capture_from_bundle))

    assert make_bundle_env(spec) is expected
    assert captured["tp_mode"] == "trailing"
    assert captured["tp_reference"] == "structural"
    assert captured["target_timeframes"] == ("M3", "M10", "H4", "D1")
    assert captured["scheduled_session_closes"] == {"2025-06-02": "20:00"}
    assert captured["session_start"] == "16:15"


def test_worker_import_does_not_load_torch_or_sb3() -> None:
    """Bundle worker imports remain independent of the training stack."""
    result = subprocess.run(
        [
            sys.executable,
            "-c",
            "import simulation.environment.worker, sys; "
            "assert 'torch' not in sys.modules; "
            "assert 'stable_baselines3' not in sys.modules",
        ],
        check=False,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr


def test_worker_factory_matches_strategy_actions(tmp_path: Path) -> None:
    """The strategy-action risk ranges and strategy flags survive serialization."""
    from configuration import load_config
    from simulation.environment.bundles import build_env_bundle
    from simulation.environment.spec import EnvSpec
    from simulation.environment.worker import make_bundle_env
    from trading.strategies import BaselineStrategy
    from training.setup.environments import make_env

    bars = _make_deterministic_bars(n=96)
    features = _make_features(bars)
    features["atr_5"] = np.linspace(1.0, 3.0, len(bars))
    cfg = load_config()
    cfg.costs.use_tick_execution = False
    cfg.execution.randomized_fill_latency_ms = 0.0
    cfg.env.strategy_actions = True
    cfg.strategy.name = "baseline"
    bundle_path = build_env_bundle(
        tmp_path,
        bars,
        features,
        cfg,
        raw_columns=list(BaselineStrategy().raw_columns),
        feature_config_hash="worker-strategy-v1",
        tickbook=None,
        pre_ny_by_date=None,
    )
    spec = EnvSpec.from_cfg(
        cfg,
        algo="ppo",
        reward="dsr",
        arch="tcn",
        bundle_dir=str(bundle_path),
    )
    frames = make_env(bars, features, cfg, algo="ppo", reward="dsr", arch="tcn")
    shared = make_bundle_env(spec)
    assert frames.action_space == shared.action_space
    assert frames.risk_frac_range == shared.risk_frac_range
    assert frames.rr_ratio_range == shared.rr_ratio_range
    assert frames._max_tp_dist is not None
    assert shared._max_tp_dist is not None
    np.testing.assert_array_equal(frames._max_tp_dist, shared._max_tp_dist)


def test_mtf_reasoning_worker_preserves_mtf_and_thesis_observations(tmp_path: Path) -> None:
    import pandas as pd

    from configuration import load_config
    from features.context.thesis_candidates import thesis_candidate_feature_columns
    from simulation.environment.bundles import build_env_bundle
    from simulation.environment.spec import EnvSpec
    from simulation.environment.worker import make_bundle_env
    from trading.strategies import BaselineStrategy, PO3IFVGStrategy
    from training.setup.environments import make_env

    bars = _make_deterministic_bars(n=96)
    features = _make_features(bars)
    columns = [name for _, name in thesis_candidate_feature_columns()]
    features = pd.concat(
        [
            features,
            pd.DataFrame(
                0.0,
                index=features.index,
                columns=list(PO3IFVGStrategy.required_features),
            ),
            pd.DataFrame(0.0, index=features.index, columns=columns),
        ],
        axis=1,
    )
    config = load_config(config_path="config/research/thesis_mtf_reasoning.yaml")
    config.costs.use_tick_execution = False
    config.execution.randomized_fill_latency_ms = 0.0
    bundle_path = build_env_bundle(
        tmp_path,
        bars,
        features,
        config,
        raw_columns=list(BaselineStrategy().raw_columns),
        feature_config_hash="mtf-reasoning-thesis-worker-v1",
        tickbook=None,
        pre_ny_by_date=None,
    )
    spec = EnvSpec.from_cfg(
        config,
        algo="ppo",
        reward="dsr",
        arch="mtf_reasoning",
        bundle_dir=str(bundle_path),
    )

    env = make_bundle_env(spec)
    observation, _ = env.reset(seed=41)
    shared = make_env(bars, features, config, algo="ppo", reward="dsr", arch="mtf_reasoning")
    shared_observation, _ = shared.reset(seed=41)
    assert set(observation) == set(shared_observation)
    for key in observation:
        np.testing.assert_array_equal(observation[key], shared_observation[key])

    assert {
        "seq_m3",
        "seq_m5",
        "seq_m10",
        "seq_m15",
        "seq_m30",
        "seq_h1",
        "seq_h4",
        "seq_d1",
        "mask_m3",
        "mask_m5",
        "mask_m10",
        "mask_m15",
        "mask_m30",
        "mask_h1",
        "mask_h4",
        "mask_d1",
        "thesis_mask",
    } <= set(observation)

    for arch in (
        "mtf_shared_tcn_reasoning",
        "mtf_m1_tcn_htf_lite_reasoning",
        "mtf_m1_tcn_htf_snapshot_reasoning",
    ):
        variant_spec = EnvSpec.from_cfg(
            config,
            algo="ppo",
            reward="dsr",
            arch=arch,
            bundle_dir=str(bundle_path),
        )
        variant_env = make_bundle_env(variant_spec)
        variant_observation, _ = variant_env.reset(seed=41)
        assert "seq_m3" in variant_observation
        assert "mask_d1" in variant_observation
        variant_env.close()


@pytest.mark.parametrize("name", ["po3_ifvg", "distribution", "unrecognized"])
def test_worker_recreates_named_strategy(name: str) -> None:
    """Each strategy name reconstructs its existing class and reward type."""
    from simulation.environment.distribution_reward import DistributionReward
    from simulation.environment.po3_reward import PO3Reward
    from simulation.environment.worker import _strategy
    from trading.strategies import BaselineStrategy, DistributionStrategy, PO3IFVGStrategy

    strategy, reward, weight = _strategy(
        {
            "strategy": {
                "name": name,
                "manipulation_filter": "follow",
                "ifvg": {"require_price_retest": False},
                "reward": {"strategy_weight": 0.25},
            }
        },
        True,
    )
    assert weight == (0.0 if name == "unrecognized" else 0.25)
    if name == "po3_ifvg":
        assert isinstance(strategy, PO3IFVGStrategy)
        assert isinstance(reward, PO3Reward)
        assert strategy.require_price_retest is False
    elif name == "distribution":
        assert isinstance(strategy, DistributionStrategy)
        assert isinstance(reward, DistributionReward)
    else:
        assert isinstance(strategy, BaselineStrategy)
        assert reward is None


def test_env_spec_pickle_is_small(tmp_path: Path) -> None:
    """The worker payload contains only a bundle path and scalar config."""
    from simulation.environment.spec import EnvSpec

    spec = EnvSpec.from_cfg(
        {"env": {"obs_window": 60}, "account": {"initial_balance": 100_000}},
        algo="ppo",
        reward="dsr",
        arch="tcn",
        bundle_dir=str(tmp_path),
    )
    assert len(pickle.dumps(spec)) < 1_000_000
